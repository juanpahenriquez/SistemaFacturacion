﻿namespace Practica1
{
    partial class Registros
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
            button6 = new Button();
            label5 = new Label();
            button5 = new Button();
            button4 = new Button();
            label1 = new Label();
            btnReportes = new Button();
            btnFacturas = new Button();
            btnClientes = new Button();
            btnCrudProductos = new Button();
            panelSidebar = new Panel();
            button3 = new Button();
            label3 = new Label();
            button2 = new Button();
            button1 = new Button();
            label2 = new Label();
            pictureBox1 = new PictureBox();
            btnProductos = new Button();
            panelTop = new Panel();
            labelTitulo = new Label();
            label6 = new Label();
            label7 = new Label();
            panelContent = new Panel();
            textBox1 = new TextBox();
            label4 = new Label();
            button7 = new Button();
            dataGridView1 = new DataGridView();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            Column4 = new DataGridViewTextBoxColumn();
            Column5 = new DataGridViewTextBoxColumn();
            Column6 = new DataGridViewTextBoxColumn();
            Column7 = new DataGridViewTextBoxColumn();
            panelSidebar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panelTop.SuspendLayout();
            panelContent.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // button6
            // 
            button6.BackColor = Color.Indigo;
            button6.FlatAppearance.BorderSize = 0;
            button6.FlatStyle = FlatStyle.Flat;
            button6.Font = new Font("Century Schoolbook", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            button6.ForeColor = Color.White;
            button6.Location = new Point(12, 896);
            button6.Name = "button6";
            button6.Size = new Size(213, 41);
            button6.TabIndex = 16;
            button6.Text = "⚙️ Configuracion";
            button6.UseVisualStyleBackColor = false;
            button6.Click += button6_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.FromArgb(138, 138, 255);
            label5.Font = new Font("Copperplate Gothic Light", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.White;
            label5.Location = new Point(60, 863);
            label5.Name = "label5";
            label5.Size = new Size(135, 25);
            label5.TabIndex = 15;
            label5.Text = "GENERAL";
            // 
            // button5
            // 
            button5.BackColor = Color.Indigo;
            button5.FlatAppearance.BorderSize = 0;
            button5.FlatStyle = FlatStyle.Flat;
            button5.Font = new Font("Century Schoolbook", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            button5.ForeColor = Color.White;
            button5.Location = new Point(12, 782);
            button5.Name = "button5";
            button5.Size = new Size(213, 41);
            button5.TabIndex = 14;
            button5.Text = "⌨️ CRUD Admin";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // button4
            // 
            button4.BackColor = Color.Indigo;
            button4.FlatAppearance.BorderSize = 0;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Century Schoolbook", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            button4.ForeColor = Color.White;
            button4.Location = new Point(12, 735);
            button4.Name = "button4";
            button4.Size = new Size(213, 41);
            button4.TabIndex = 13;
            button4.Text = "🚻 CRUD Clientes";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.FromArgb(138, 138, 255);
            label1.Font = new Font("Copperplate Gothic Light", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(69, 220);
            label1.Name = "label1";
            label1.Size = new Size(129, 25);
            label1.TabIndex = 7;
            label1.Text = "Principal";
            // 
            // btnReportes
            // 
            btnReportes.BackColor = Color.Indigo;
            btnReportes.FlatAppearance.BorderSize = 0;
            btnReportes.FlatStyle = FlatStyle.Flat;
            btnReportes.Font = new Font("Century Schoolbook", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnReportes.ForeColor = Color.White;
            btnReportes.Location = new Point(12, 254);
            btnReportes.Name = "btnReportes";
            btnReportes.Size = new Size(213, 41);
            btnReportes.TabIndex = 5;
            btnReportes.Text = "📉 Dashboard";
            btnReportes.UseVisualStyleBackColor = false;
            btnReportes.Click += btnReportes_Click;
            // 
            // btnFacturas
            // 
            btnFacturas.BackColor = Color.Indigo;
            btnFacturas.FlatAppearance.BorderSize = 0;
            btnFacturas.FlatStyle = FlatStyle.Flat;
            btnFacturas.Font = new Font("Century Schoolbook", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnFacturas.ForeColor = Color.White;
            btnFacturas.Location = new Point(12, 348);
            btnFacturas.Name = "btnFacturas";
            btnFacturas.Size = new Size(213, 41);
            btnFacturas.TabIndex = 3;
            btnFacturas.Text = "📖 Historial";
            btnFacturas.UseVisualStyleBackColor = false;
            btnFacturas.Click += btnFacturas_Click;
            // 
            // btnClientes
            // 
            btnClientes.BackColor = Color.Indigo;
            btnClientes.FlatAppearance.BorderSize = 0;
            btnClientes.FlatStyle = FlatStyle.Flat;
            btnClientes.Font = new Font("Century Schoolbook", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnClientes.ForeColor = Color.White;
            btnClientes.Location = new Point(12, 301);
            btnClientes.Name = "btnClientes";
            btnClientes.Size = new Size(213, 41);
            btnClientes.TabIndex = 2;
            btnClientes.Text = "🗓️ Registro";
            btnClientes.UseVisualStyleBackColor = false;
            btnClientes.Click += btnClientes_Click;
            // 
            // btnCrudProductos
            // 
            btnCrudProductos.BackColor = Color.Indigo;
            btnCrudProductos.FlatAppearance.BorderSize = 0;
            btnCrudProductos.FlatStyle = FlatStyle.Flat;
            btnCrudProductos.Font = new Font("Century Schoolbook", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnCrudProductos.ForeColor = Color.White;
            btnCrudProductos.Location = new Point(12, 583);
            btnCrudProductos.Name = "btnCrudProductos";
            btnCrudProductos.Size = new Size(213, 41);
            btnCrudProductos.TabIndex = 17;
            btnCrudProductos.Text = "🍔PRODUCTOS";
            btnCrudProductos.UseVisualStyleBackColor = false;
            btnCrudProductos.Click += btnCrudProductos_Click;
            // 
            // panelSidebar
            // 
            panelSidebar.BackColor = Color.FromArgb(138, 138, 255);
            panelSidebar.Controls.Add(btnCrudProductos);
            panelSidebar.Controls.Add(button6);
            panelSidebar.Controls.Add(label5);
            panelSidebar.Controls.Add(button5);
            panelSidebar.Controls.Add(button4);
            panelSidebar.Controls.Add(button3);
            panelSidebar.Controls.Add(label3);
            panelSidebar.Controls.Add(button2);
            panelSidebar.Controls.Add(button1);
            panelSidebar.Controls.Add(label2);
            panelSidebar.Controls.Add(label1);
            panelSidebar.Controls.Add(pictureBox1);
            panelSidebar.Controls.Add(btnReportes);
            panelSidebar.Controls.Add(btnProductos);
            panelSidebar.Controls.Add(btnFacturas);
            panelSidebar.Controls.Add(btnClientes);
            panelSidebar.Dock = DockStyle.Left;
            panelSidebar.Location = new Point(0, 0);
            panelSidebar.Name = "panelSidebar";
            panelSidebar.Size = new Size(241, 1055);
            panelSidebar.TabIndex = 2;
            // 
            // button3
            // 
            button3.BackColor = Color.Indigo;
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Century Schoolbook", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            button3.ForeColor = Color.White;
            button3.Location = new Point(12, 688);
            button3.Name = "button3";
            button3.Size = new Size(213, 41);
            button3.TabIndex = 12;
            button3.Text = "👨CRUD Empleados";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.FromArgb(138, 138, 255);
            label3.Font = new Font("Copperplate Gothic Light", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.White;
            label3.Location = new Point(70, 644);
            label3.Name = "label3";
            label3.Size = new Size(125, 25);
            label3.TabIndex = 11;
            label3.Text = "Usuarios";
            // 
            // button2
            // 
            button2.BackColor = Color.Indigo;
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Century Schoolbook", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.White;
            button2.Location = new Point(12, 533);
            button2.Name = "button2";
            button2.Size = new Size(213, 41);
            button2.TabIndex = 10;
            button2.Text = "✉️ DTE";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.Indigo;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Century Schoolbook", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.White;
            button1.Location = new Point(12, 486);
            button1.Name = "button1";
            button1.Size = new Size(213, 41);
            button1.TabIndex = 9;
            button1.Text = "💰 Contabilidad";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.FromArgb(138, 138, 255);
            label2.Font = new Font("Copperplate Gothic Light", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(28, 402);
            label2.Name = "label2";
            label2.Size = new Size(197, 25);
            label2.TabIndex = 8;
            label2.Text = "Administrativo";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Control_Panel_bro;
            pictureBox1.Location = new Point(30, 25);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(195, 182);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 6;
            pictureBox1.TabStop = false;
            // 
            // btnProductos
            // 
            btnProductos.BackColor = Color.Indigo;
            btnProductos.FlatAppearance.BorderSize = 0;
            btnProductos.FlatStyle = FlatStyle.Flat;
            btnProductos.Font = new Font("Century Schoolbook", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnProductos.ForeColor = Color.White;
            btnProductos.Location = new Point(12, 439);
            btnProductos.Name = "btnProductos";
            btnProductos.Size = new Size(213, 41);
            btnProductos.TabIndex = 4;
            btnProductos.Text = "📚 CRUD Facturas";
            btnProductos.UseVisualStyleBackColor = false;
            btnProductos.Click += btnProductos_Click;
            // 
            // panelTop
            // 
            panelTop.BackColor = Color.FromArgb(138, 138, 255);
            panelTop.Controls.Add(labelTitulo);
            panelTop.Controls.Add(label6);
            panelTop.Controls.Add(label7);
            panelTop.Dock = DockStyle.Top;
            panelTop.Location = new Point(241, 0);
            panelTop.Name = "panelTop";
            panelTop.Size = new Size(1683, 145);
            panelTop.TabIndex = 3;
            // 
            // labelTitulo
            // 
            labelTitulo.AutoSize = true;
            labelTitulo.Font = new Font("Copperplate Gothic Light", 20F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelTitulo.ForeColor = Color.White;
            labelTitulo.Location = new Point(30, 50);
            labelTitulo.Name = "labelTitulo";
            labelTitulo.Size = new Size(236, 37);
            labelTitulo.TabIndex = 16;
            labelTitulo.Text = "REGISTROS";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.Location = new Point(-10, 56);
            label6.Name = "label6";
            label6.Size = new Size(20, 31);
            label6.TabIndex = 15;
            label6.Text = "|";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.Location = new Point(-10, 25);
            label7.Name = "label7";
            label7.Size = new Size(20, 31);
            label7.TabIndex = 3;
            label7.Text = "|";
            // 
            // panelContent
            // 
            panelContent.BackColor = Color.White;
            panelContent.Controls.Add(textBox1);
            panelContent.Controls.Add(label4);
            panelContent.Controls.Add(button7);
            panelContent.Controls.Add(dataGridView1);
            panelContent.Dock = DockStyle.Fill;
            panelContent.Location = new Point(241, 145);
            panelContent.Name = "panelContent";
            panelContent.Padding = new Padding(20);
            panelContent.Size = new Size(1683, 910);
            panelContent.TabIndex = 4;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(498, 55);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(538, 27);
            textBox1.TabIndex = 3;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Copperplate Gothic Light", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(698, 27);
            label4.Name = "label4";
            label4.Size = new Size(148, 25);
            label4.TabIndex = 2;
            label4.Text = "BUSCAR 🔎";
            // 
            // button7
            // 
            button7.BackColor = Color.FromArgb(192, 192, 255);
            button7.Font = new Font("Copperplate Gothic Light", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button7.Location = new Point(46, 34);
            button7.Name = "button7";
            button7.Size = new Size(164, 49);
            button7.TabIndex = 1;
            button7.Text = "GENERAR ➕";
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.AllowUserToResizeRows = false;
            dataGridViewCellStyle4.BackColor = Color.FromArgb(240, 240, 250);
            dataGridViewCellStyle4.ForeColor = Color.FromArgb(45, 45, 68);
            dataGridViewCellStyle4.SelectionBackColor = Color.FromArgb(138, 138, 255);
            dataGridViewCellStyle4.SelectionForeColor = Color.White;
            dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            dataGridView1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dataGridView1.BackgroundColor = Color.White;
            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridView1.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle5.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = Color.FromArgb(107, 107, 217);
            dataGridViewCellStyle5.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            dataGridViewCellStyle5.ForeColor = Color.White;
            dataGridViewCellStyle5.Padding = new Padding(12, 10, 12, 10);
            dataGridViewCellStyle5.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = DataGridViewTriState.True;
            dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            dataGridView1.ColumnHeadersHeight = 52;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { Column1, Column2, Column3, Column4, Column5, Column6, Column7 });
            dataGridViewCellStyle6.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = Color.White;
            dataGridViewCellStyle6.Font = new Font("Segoe UI", 10F);
            dataGridViewCellStyle6.ForeColor = Color.FromArgb(45, 45, 68);
            dataGridViewCellStyle6.Padding = new Padding(12, 0, 12, 0);
            dataGridViewCellStyle6.SelectionBackColor = Color.FromArgb(138, 138, 255);
            dataGridViewCellStyle6.SelectionForeColor = Color.White;
            dataGridViewCellStyle6.WrapMode = DataGridViewTriState.False;
            dataGridView1.DefaultCellStyle = dataGridViewCellStyle6;
            dataGridView1.EnableHeadersVisualStyles = false;
            dataGridView1.GridColor = Color.FromArgb(216, 216, 232);
            dataGridView1.Location = new Point(54, 111);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.RowTemplate.Height = 48;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.Size = new Size(1606, 766);
            dataGridView1.TabIndex = 0;
            // 
            // Column1
            // 
            Column1.HeaderText = "ID";
            Column1.MinimumWidth = 6;
            Column1.Name = "Column1";
            Column1.ReadOnly = true;
            Column1.Width = 125;
            // 
            // Column2
            // 
            Column2.HeaderText = "Fecha";
            Column2.MinimumWidth = 6;
            Column2.Name = "Column2";
            Column2.ReadOnly = true;
            Column2.Width = 250;
            // 
            // Column3
            // 
            Column3.HeaderText = "Nombre";
            Column3.MinimumWidth = 6;
            Column3.Name = "Column3";
            Column3.ReadOnly = true;
            Column3.Width = 300;
            // 
            // Column4
            // 
            Column4.HeaderText = "Documento";
            Column4.MinimumWidth = 6;
            Column4.Name = "Column4";
            Column4.ReadOnly = true;
            Column4.Width = 300;
            // 
            // Column5
            // 
            Column5.HeaderText = "Editar";
            Column5.MinimumWidth = 6;
            Column5.Name = "Column5";
            Column5.ReadOnly = true;
            Column5.Width = 250;
            // 
            // Column6
            // 
            Column6.HeaderText = "Eliminar";
            Column6.MinimumWidth = 6;
            Column6.Name = "Column6";
            Column6.ReadOnly = true;
            Column6.Width = 200;
            // 
            // Column7
            // 
            Column7.HeaderText = "Imprimir";
            Column7.MinimumWidth = 6;
            Column7.Name = "Column7";
            Column7.ReadOnly = true;
            Column7.Width = 200;
            // 
            // Registros
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1924, 1055);
            Controls.Add(panelContent);
            Controls.Add(panelTop);
            Controls.Add(panelSidebar);
            Name = "Registros";
            Text = "Registros";
            WindowState = FormWindowState.Maximized;
            panelSidebar.ResumeLayout(false);
            panelSidebar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panelTop.ResumeLayout(false);
            panelTop.PerformLayout();
            panelContent.ResumeLayout(false);
            panelContent.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Button button6;
        private Label label5;
        private Button button5;
        private Button button4;
        private Label label1;
        private Button btnReportes;
        private Button btnFacturas;
        private Button btnClientes;
        private Button btnCrudProductos;
        private Panel panelSidebar;
        private Button button3;
        private Label label3;
        private Button button2;
        private Button button1;
        private Label label2;
        private PictureBox pictureBox1;
        private Button btnProductos;
        private Panel panelTop;
        private Label labelTitulo;
        private Label label6;
        private Label label7;
        private Panel panelContent;
        private DataGridView dataGridView1;
        private Button button7;
        private TextBox textBox1;
        private Label label4;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private DataGridViewTextBoxColumn Column4;
        private DataGridViewTextBoxColumn Column5;
        private DataGridViewTextBoxColumn Column6;
        private DataGridViewTextBoxColumn Column7;
    }
}
