﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practica1.Clases
{
    internal class conexion
    {

        private  static string servidor = "localhost";
        private static string puerto = "3307";
        private static string usuario = "root";
        private static string clave = "";
        private static string baseDatos = "practica_db";


        private static string cadenaConexion =
            $"Server={servidor}; Port={puerto}; Database={baseDatos}; Uid={usuario}; Pwd={clave};";

        public static MySqlConnection ObtenerConexion()
        {
            return new MySqlConnection(cadenaConexion);
        }

    }
}
