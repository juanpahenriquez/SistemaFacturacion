﻿using MySql.Data.MySqlClient;
using Practica1.Clases;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica1
{
    public partial class CrudAdmin : Form
    {
        public CrudAdmin()
        {
            InitializeComponent();
            HacerBotonesSidebarTransparentes();
            CargarAdmins();
        }

        private void HacerBotonesSidebarTransparentes()
        {
            Button[] sidebar = new Button[]
            {
                btnReportes, btnClientes, btnFacturas, btnProductos,
                button1, button2, btnCrudProductos, button3,
                button4, button5, button6
            };

            foreach (var btn in sidebar)
            {
                HacerBotonTransparente(btn);
            }
        }

        private void HacerBotonTransparente(Button btn)
        {
            // Re-parent al pictureBox para transparencia real sobre la imagen
            var posForm = btn.Location;
            btn.Parent = pictureBox1;
            btn.Location = new Point(
                posForm.X - pictureBox1.Location.X,
                posForm.Y - pictureBox1.Location.Y);

            btn.BackColor = Color.Transparent;
            btn.ForeColor = Color.FromArgb(0, 255, 255, 255);
            btn.Text = string.Empty;
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
            btn.FlatAppearance.BorderColor = Color.FromArgb(0, 255, 255, 255);
            btn.FlatAppearance.MouseOverBackColor = Color.FromArgb(0, 255, 255, 255);
            btn.FlatAppearance.MouseDownBackColor = Color.FromArgb(0, 255, 255, 255);
            btn.FlatAppearance.CheckedBackColor = Color.FromArgb(0, 255, 255, 255);
            btn.UseVisualStyleBackColor = false;
            btn.BringToFront();
        }

        private void btnReportes_Click(object sender, EventArgs e)
        {
            FormDashboard dashboard = new FormDashboard();
            dashboard.Show();
            this.Hide();
        }

        private void btnClientes_Click(object sender, EventArgs e)
        {
            Registros registros = new Registros();
            registros.Show();
            this.Hide();
        }

        private void btnFacturas_Click(object sender, EventArgs e)
        {
            Historial historial = new Historial();
            historial.Show();
            this.Hide();
        }

        private void btnProductos_Click(object sender, EventArgs e)
        {
            CRUDFACTURAS cRUDFACTURAS = new CRUDFACTURAS();
            cRUDFACTURAS.Show();
            this.Hide();
        }

        private void btnCrudProductos_Click(object sender, EventArgs e)
        {
            CRUDPRODUCTOS cRUDPRODUCTOS = new CRUDPRODUCTOS();
            cRUDPRODUCTOS.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Contabilidad contabilidad = new Contabilidad();
            contabilidad.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DTE dte = new DTE();
            dte.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            CrudEmpleados crudEmpleados = new CrudEmpleados();
            crudEmpleados.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            CrudClientes crudclientes = new CrudClientes();
            crudclientes.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            CrudAdmin crudadmin = new CrudAdmin();
            crudadmin.Show();
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Configuracion configuracion = new Configuracion();
            configuracion.Show();
            this.Hide();
        }

        private void btnGenerar_Click(object sender, EventArgs e)
        {
            FormAdmin formAdmin = new FormAdmin();
            if (formAdmin.ShowDialog() == DialogResult.OK)
            {
                CargarAdmins();
            }
        }

        public void CargarAdmins()
        {
            string query = "Select id, nombre, apellido, correo, telefono, estado FROM admin";

            using (MySqlConnection conn = conexion.ObtenerConexion())
            {
                try
                {
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    MySqlDataReader reader = cmd.ExecuteReader();

                    dgvAdmin.Rows.Clear();

                    while (reader.Read())
                    {
                        dgvAdmin.Rows.Add(
                            reader["id"].ToString(),
                            reader["nombre"].ToString(),
                            reader["apellido"].ToString(),
                            reader["telefono"].ToString(),
                            reader["correo"].ToString(),
                            reader["estado"].ToString()
                        );
                    }
                }

                catch (Exception ex)
                {
                    MessageBox.Show("Error al cargar administradores: " + ex.Message, "Error",
                       MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
