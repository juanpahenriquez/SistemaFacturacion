﻿using Practica1.Clases;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Practica1
{
    public partial class CRUDPRODUCTOS : Form
    {
        public CRUDPRODUCTOS()
        {
            InitializeComponent();
            HacerBotonesSidebarTransparentes();
            dgvProductos.CellContentClick += dgvProductos_CellContentClick;
            CargarProductos();
        }

        private void HacerBotonesSidebarTransparentes()
        {
            Button[] sidebar = new Button[]
            {
                btnReportes, btnClientes, btnFacturas, btnProductos,
                button1, button2, btnCrudProductos, button3,
                button4, button5, button6
            };

            foreach (var btn in sidebar)
            {
                HacerBotonTransparente(btn);
            }
        }

        private void HacerBotonTransparente(Button btn)
        {
            // Re-parent al pictureBox para transparencia real sobre la imagen
            var posForm = btn.Location;
            btn.Parent = pictureBox1;
            btn.Location = new Point(
                posForm.X - pictureBox1.Location.X,
                posForm.Y - pictureBox1.Location.Y);

            btn.BackColor = Color.Transparent;
            btn.ForeColor = Color.FromArgb(0, 255, 255, 255);
            btn.Text = string.Empty;
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
            btn.FlatAppearance.BorderColor = Color.FromArgb(0, 255, 255, 255);
            btn.FlatAppearance.MouseOverBackColor = Color.FromArgb(0, 255, 255, 255);
            btn.FlatAppearance.MouseDownBackColor = Color.FromArgb(0, 255, 255, 255);
            btn.FlatAppearance.CheckedBackColor = Color.FromArgb(0, 255, 255, 255);
            btn.UseVisualStyleBackColor = false;
            btn.BringToFront();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            FormProductos formProductos = new FormProductos();
            if (formProductos.ShowDialog() == DialogResult.OK )
            {
                CargarProductos();
            }
        }

        private void btnReportes_Click(object sender, EventArgs e)
        {
            FormDashboard formDashboard = new FormDashboard();
            formDashboard.Show();
            this.Hide();
        }

        private void btnClientes_Click(object sender, EventArgs e)
        {
            Registros registros = new Registros();
            registros.Show();
            this.Hide();
        }

        private void btnFacturas_Click(object sender, EventArgs e)
        {
            Historial historial = new Historial();
            historial.Show();
            this.Hide();
        }

        private void btnProductos_Click(object sender, EventArgs e)
        {
            CRUDFACTURAS cRUDFACTURAS = new CRUDFACTURAS();
            cRUDFACTURAS.Show();
            this.Hide();
        }

        private void btnCrudProductos_Click(object sender, EventArgs e)
        {
            CRUDPRODUCTOS cRUDPRODUCTOS = new CRUDPRODUCTOS();
            cRUDPRODUCTOS.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Contabilidad contabilidad = new Contabilidad();
            contabilidad.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DTE dte = new DTE();
            dte.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            CrudEmpleados crudEmpleados = new CrudEmpleados();
            crudEmpleados.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            CrudClientes crudClientes = new CrudClientes();
            crudClientes.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            CrudAdmin crudAdmin = new CrudAdmin();
            crudAdmin.Show();
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Configuracion configuracion = new Configuracion();
            configuracion.Show();
            this.Hide();
        }

        public void CargarProductos()
        {
            string query = "Select id, nombre, categoria, precio FROM productos";

            using (MySqlConnection conn = conexion.ObtenerConexion())
            {
                try
                {
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    MySqlDataReader reader = cmd.ExecuteReader();

                    dgvProductos.Rows.Clear();

                    while (reader.Read())
                    {
                        dgvProductos.Rows.Add(
                            reader["id"].ToString(),
                            reader["nombre"].ToString(),
                             reader["categoria"].ToString(),
                             Convert.ToDecimal(reader["precio"]).ToString("C2"),
                             "Activo"
                        );

                    }
                }

                catch (Exception ex)
                {
                    MessageBox.Show("Error al cargar productos: " + ex.Message, "Error",
                       MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
        }

        }

        private void dgvProductos_CellContentClick(object? sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            int id = Convert.ToInt32(dgvProductos.Rows[e.RowIndex].Cells["colID"].Value);

            if (e.ColumnIndex == dgvProductos.Columns["Editar"].Index)
            {
                FormProductos formEditar = new FormProductos(id);
                if (formEditar.ShowDialog() == DialogResult.OK)
                {
                    CargarProductos();
                }
            }
            else if (e.ColumnIndex == dgvProductos.Columns["Eliminar"].Index)
            {
                DialogResult result = MessageBox.Show("¿Desea eliminar este producto?", "Confirmar",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    EliminarProducto(id);
                }
            }
        }

        private void EliminarProducto(int id)
        {
            string query = "DELETE FROM productos WHERE id = @id";

            using (MySqlConnection conn = conexion.ObtenerConexion())
            {
                try
                {
                    conn.Open();
                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.ExecuteNonQuery();
                    }
                    CargarProductos();
                    MessageBox.Show("Producto eliminado con éxito.", "Éxito",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (MySqlException ex) when (ex.Number == 1451)
                {
                    MessageBox.Show("No se puede eliminar: el producto está usado en una factura.", "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al eliminar producto: " + ex.Message, "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

    }


}