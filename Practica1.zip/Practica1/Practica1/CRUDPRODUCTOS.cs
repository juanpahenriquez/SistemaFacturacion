﻿using Practica1.Clases;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Practica1
{
    public partial class CRUDPRODUCTOS : Form
    {
        public CRUDPRODUCTOS()
        {
            InitializeComponent();
            CargarProductos();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            FormProductos formProductos = new FormProductos();
            if (formProductos.ShowDialog() == DialogResult.OK )
            {
                CargarProductos();
            }
        }

        private void btnReportes_Click(object sender, EventArgs e)
        {
            FormDashboard formDashboard = new FormDashboard();
            formDashboard.Show();
            this.Hide();
        }

        private void btnClientes_Click(object sender, EventArgs e)
        {
            Registros registros = new Registros();
            registros.Show();
            this.Hide();
        }

        private void btnFacturas_Click(object sender, EventArgs e)
        {
            Historial historial = new Historial();
            historial.Show();
            this.Hide();
        }

        private void btnProductos_Click(object sender, EventArgs e)
        {
            CRUDFACTURAS cRUDFACTURAS = new CRUDFACTURAS();
            cRUDFACTURAS.Show();
            this.Hide();
        }

        private void btnCrudProductos_Click(object sender, EventArgs e)
        {
            CRUDPRODUCTOS cRUDPRODUCTOS = new CRUDPRODUCTOS();
            cRUDPRODUCTOS.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Contabilidad contabilidad = new Contabilidad();
            contabilidad.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DTE dte = new DTE();
            dte.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            CrudEmpleados crudEmpleados = new CrudEmpleados();
            crudEmpleados.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            CrudClientes crudClientes = new CrudClientes();
            crudClientes.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            CrudAdmin crudAdmin = new CrudAdmin();
            crudAdmin.Show();
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Configuracion configuracion = new Configuracion();
            configuracion.Show();
            this.Hide();
        }

        public void CargarProductos()
        {
            string query = "Select id, nombre, categoria, precio FROM productos";

            using (MySqlConnection conn = conexion.ObtenerConexion())
            {
                try
                {
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    MySqlDataReader reader = cmd.ExecuteReader();

                    dgvProductos.Rows.Clear();

                    while (reader.Read())
                    {
                        dgvProductos.Rows.Add(
                            reader["id"].ToString(),
                            reader["nombre"].ToString(),
                             reader["categoria"].ToString(),
                             Convert.ToDecimal(reader["precio"]).ToString("C2"),
                             "Activo"
                        );

                    }
                }

                catch (Exception ex)
                {
                    MessageBox.Show("Error al cargar productos: " + ex.Message, "Error",
                       MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
        }

        }

    }


}