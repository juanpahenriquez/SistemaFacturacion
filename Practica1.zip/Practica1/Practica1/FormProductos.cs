﻿using MySql.Data.MySqlClient;
using Practica1.Clases;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Practica1
{
    public partial class FormProductos : Form
    {
        private int? _idEditar = null;

        public FormProductos()
        {
            InitializeComponent();
            HacerBotonesTransparentes();
        }

        private void HacerBotonesTransparentes()
        {
            System.Windows.Forms.Button[] botones = new System.Windows.Forms.Button[] { btnCerrar, btnRegistrar };

            foreach (var btn in botones)
            {
                HacerBotonTransparente(btn);
            }
        }

        private void HacerBotonTransparente(System.Windows.Forms.Button btn)
        {
            // Re-parent al pictureBox para transparencia real sobre la imagen
            var posForm = btn.Location;
            btn.Parent = pictureBox1;
            btn.Location = new Point(
                posForm.X - pictureBox1.Location.X,
                posForm.Y - pictureBox1.Location.Y);

            btn.BackColor = Color.Transparent;
            btn.ForeColor = Color.FromArgb(0, 255, 255, 255);
            btn.Text = string.Empty;
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
            btn.FlatAppearance.BorderColor = Color.FromArgb(0, 255, 255, 255);
            btn.FlatAppearance.MouseOverBackColor = Color.FromArgb(0, 255, 255, 255);
            btn.FlatAppearance.MouseDownBackColor = Color.FromArgb(0, 255, 255, 255);
            btn.FlatAppearance.CheckedBackColor = Color.FromArgb(0, 255, 255, 255);
            btn.UseVisualStyleBackColor = false;
            btn.BringToFront();
        }

        public FormProductos(int id) : this()
        {
            _idEditar = id;
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            string nombre = txtNombre.Text.Trim();
            string categoria = cmbCategoria.Text.Trim();
            string precioTexto = txtPrecio.Text.Trim();

            if (string.IsNullOrEmpty(nombre) || string.IsNullOrEmpty(categoria) || string.IsNullOrEmpty(precioTexto))
            {
                MessageBox.Show("Por favor complete todos los campos antes de guardar.", "Atención",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!decimal.TryParse(precioTexto, out decimal precio))
            {
                MessageBox.Show("Ingrese un valor numérico válido para el precio.", "Error de formato",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            bool esEdicion = _idEditar.HasValue;
            string query = esEdicion
                ? "UPDATE productos SET nombre = @nombre, categoria = @categoria, precio = @precio WHERE id = @id"
                : "INSERT INTO productos (nombre, categoria, precio) VALUES (@nombre, @categoria, @precio)";

            using (MySqlConnection conn = conexion.ObtenerConexion())
            {
                try
                {
                    conn.Open();
                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@nombre", nombre);
                        cmd.Parameters.AddWithValue("@categoria", categoria);
                        cmd.Parameters.AddWithValue("@precio", precio);
                        if (esEdicion)
                            cmd.Parameters.AddWithValue("@id", _idEditar!.Value);

                        cmd.ExecuteNonQuery();
                    }

                    MessageBox.Show(esEdicion ? "¡Producto actualizado con éxito!" : "¡Producto registrado con éxito!", "Éxito",
                                    MessageBoxButtons.OK, MessageBoxIcon.Information);


                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al guardar en la base de datos: " + ex.Message, "Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void FormProductos_Load(object sender, EventArgs e)
        {
            if (cmbCategoria.Items.Count == 0)
            {
                cmbCategoria.Items.Add("Electrónica");
                cmbCategoria.Items.Add("Ropa");
                cmbCategoria.Items.Add("Alimentos");
                cmbCategoria.Items.Add("Hogar");
                cmbCategoria.Items.Add("General");
            }

            if (_idEditar.HasValue)
            {
                CargarParaEditar(_idEditar.Value);
            }
        }

        private void CargarParaEditar(int id)
        {
            string query = "SELECT nombre, categoria, precio FROM productos WHERE id = @id";

            using (MySqlConnection conn = conexion.ObtenerConexion())
            {
                try
                {
                    conn.Open();
                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                txtNombre.Text = reader["nombre"].ToString();
                                cmbCategoria.Text = reader["categoria"].ToString();
                                txtPrecio.Text = Convert.ToDecimal(reader["precio"]).ToString("F2");
                            }
                            else
                            {
                                MessageBox.Show("No se encontró el producto a editar.", "Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                                this.DialogResult = DialogResult.Cancel;
                                this.Close();
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al cargar el producto: " + ex.Message, "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.DialogResult = DialogResult.Cancel;
                    this.Close();
                }
            }
        }
    }

}
