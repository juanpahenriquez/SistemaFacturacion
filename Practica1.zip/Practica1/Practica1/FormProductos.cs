﻿using MySql.Data.MySqlClient;
using Practica1.Clases;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Practica1
{
    public partial class FormProductos : Form
    {
        public FormProductos()
        {
            InitializeComponent();
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            string nombre = txtNombre.Text.Trim();
            string categoria = cmbCategoria.Text.Trim();
            string precioTexto = txtPrecio.Text.Trim();

            if (string.IsNullOrEmpty(nombre) || string.IsNullOrEmpty(categoria) || string.IsNullOrEmpty(precioTexto))
            {
                MessageBox.Show("Por favor complete todos los campos antes de guardar.", "Atención",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!decimal.TryParse(precioTexto, out decimal precio))
            {
                MessageBox.Show("Ingrese un valor numérico válido para el precio.", "Error de formato",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string query = "INSERT INTO productos (nombre, categoria, precio) VALUES (@nombre, @categoria, @precio)";

            using (MySqlConnection conn = conexion.ObtenerConexion())
            {
                try
                {
                    conn.Open();
                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@nombre", nombre);
                        cmd.Parameters.AddWithValue("@categoria", categoria);
                        cmd.Parameters.AddWithValue("@precio", precio);

                        cmd.ExecuteNonQuery();
                    }

                    MessageBox.Show("¡Producto registrado con éxito!", "Éxito",
                                    MessageBoxButtons.OK, MessageBoxIcon.Information);


                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al guardar en la base de datos: " + ex.Message, "Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void FormProductos_Load(object sender, EventArgs e)
        {
            if (cmbCategoria.Items.Count == 0)
            {
                cmbCategoria.Items.Add("Electrónica");
                cmbCategoria.Items.Add("Ropa");
                cmbCategoria.Items.Add("Alimentos");
                cmbCategoria.Items.Add("Hogar");
                cmbCategoria.Items.Add("General");
            }
        }
    }

}
