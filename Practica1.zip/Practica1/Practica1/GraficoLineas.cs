using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Windows.Forms;

namespace Practica1
{
    public class GraficoLineas : Control
    {
        private string[] _categorias;
        private double[] _valores;

        public string Title { get; set; } = "INGRESOS MENSUALES";
        public Color LineColor { get; set; } = Color.Indigo;
        public Color PointColor { get; set; } = Color.DarkViolet;
        public Color GridColor { get; set; } = Color.Silver;
        public Font TitleFont { get; set; } = new Font("Copperplate Gothic Light", 16F, FontStyle.Regular);

        public GraficoLineas()
        {
            DoubleBuffered = true;
            BackColor = Color.White;
            _categorias = new[] { "Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic" };
            _valores = new double[] { 1200, 950, 1400, 1100, 1600, 1350, 1800, 1500, 1700, 1900, 2100, 2350 };
        }

        public void SetData(string[] categorias, double[] valores)
        {
            _categorias = categorias;
            _valores = valores;
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            if (!string.IsNullOrEmpty(Title))
            {
                using (var brush = new SolidBrush(Color.Black))
                using (var format = new StringFormat { Alignment = StringAlignment.Center })
                {
                    g.DrawString(Title, TitleFont, brush, new RectangleF(0, 8, Width, 36), format);
                }
            }

            if (_valores == null || _valores.Length == 0)
            {
                return;
            }

            int marginLeft = 60, marginRight = 24, marginTop = 52, marginBottom = 42;
            Rectangle plot = new Rectangle(marginLeft, marginTop, Width - marginLeft - marginRight, Height - marginTop - marginBottom);
            if (plot.Width < 10 || plot.Height < 10)
            {
                return;
            }

            double min = Math.Min(0, _valores.Min());
            double max = _valores.Max();
            if (max == min)
            {
                max = min + 1;
            }

            int divisions = 5;
            int n = _valores.Length;

            using (var gridPen = new Pen(GridColor) { DashStyle = DashStyle.Dot })
            using (var textBrush = new SolidBrush(Color.Black))
            using (var axisPen = new Pen(Color.Black))
            using (var linePen = new Pen(LineColor, 3f))
            using (var pointBrush = new SolidBrush(PointColor))
            using (var font = new Font("Segoe UI", 9F))
            {
                for (int i = 0; i <= divisions; i++)
                {
                    float y = plot.Bottom - (float)(plot.Height * ((double)i / divisions));
                    g.DrawLine(gridPen, plot.Left, y, plot.Right, y);
                    double value = min + (max - min) * ((double)i / divisions);
                    g.DrawString(value.ToString("0"), font, textBrush, new PointF(4, y - 8));
                }

                for (int i = 0; i < n; i++)
                {
                    float x = plot.Left + (n == 1 ? 0 : (float)(plot.Width * ((double)i / (n - 1))));
                    string label = _categorias != null && i < _categorias.Length ? _categorias[i] : string.Empty;
                    using (var fmt = new StringFormat { Alignment = StringAlignment.Center })
                    {
                        g.DrawString(label, font, textBrush, new RectangleF(x - plot.Width / (2f * n), plot.Bottom + 6, plot.Width / (float)n, 20), fmt);
                    }
                }

                g.DrawLine(axisPen, plot.Left, plot.Top, plot.Left, plot.Bottom);
                g.DrawLine(axisPen, plot.Left, plot.Bottom, plot.Right, plot.Bottom);

                PointF[] points = new PointF[n];
                for (int i = 0; i < n; i++)
                {
                    float x = plot.Left + (n == 1 ? 0 : (float)(plot.Width * ((double)i / (n - 1))));
                    float y = plot.Bottom - (float)(plot.Height * ((_valores[i] - min) / (max - min)));
                    points[i] = new PointF(x, y);
                }

                g.DrawLines(linePen, points);
                foreach (PointF p in points)
                {
                    g.FillEllipse(pointBrush, p.X - 4, p.Y - 4, 8, 8);
                }
            }
        }
    }
}
