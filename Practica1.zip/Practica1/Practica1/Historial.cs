﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica1
{
    public partial class Historial : Form
    {
        public Historial()
        {
            InitializeComponent();
            ConfigurarDataGridView();
        }

private void ConfigurarDataGridView()
        {
            dataGridViewHistorial.BackgroundColor = Color.White;
            dataGridViewHistorial.BorderStyle = BorderStyle.None;
            dataGridViewHistorial.GridColor = Color.FromArgb(216, 216, 232);
            dataGridViewHistorial.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dataGridViewHistorial.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;

            dataGridViewHistorial.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(107, 107, 217);
            dataGridViewHistorial.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dataGridViewHistorial.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            dataGridViewHistorial.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewHistorial.ColumnHeadersDefaultCellStyle.Padding = new Padding(12, 10, 12, 10);
            dataGridViewHistorial.EnableHeadersVisualStyles = false;
            dataGridViewHistorial.ColumnHeadersHeight = 52;

            dataGridViewHistorial.DefaultCellStyle.BackColor = Color.White;
            dataGridViewHistorial.DefaultCellStyle.ForeColor = Color.FromArgb(45, 45, 68);
            dataGridViewHistorial.DefaultCellStyle.Font = new Font("Segoe UI", 10F);
            dataGridViewHistorial.DefaultCellStyle.SelectionBackColor = Color.FromArgb(138, 138, 255);
            dataGridViewHistorial.DefaultCellStyle.SelectionForeColor = Color.White;
            dataGridViewHistorial.DefaultCellStyle.Padding = new Padding(12, 0, 12, 0);

            dataGridViewHistorial.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(240, 240, 250);
            dataGridViewHistorial.AlternatingRowsDefaultCellStyle.ForeColor = Color.FromArgb(45, 45, 68);
            dataGridViewHistorial.AlternatingRowsDefaultCellStyle.SelectionBackColor = Color.FromArgb(138, 138, 255);
            dataGridViewHistorial.AlternatingRowsDefaultCellStyle.SelectionForeColor = Color.White;

            dataGridViewHistorial.RowTemplate.Height = 48;
            dataGridViewHistorial.RowHeadersVisible = false;

            dataGridViewHistorial.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            dataGridViewHistorial.Columns["colID"].FillWeight = 15;
            dataGridViewHistorial.Columns["colCliente"].FillWeight = 30;
            dataGridViewHistorial.Columns["colFecha"].FillWeight = 20;
            dataGridViewHistorial.Columns["colTotal"].FillWeight = 15;
            dataGridViewHistorial.Columns["colEstado"].FillWeight = 20;

            dataGridViewHistorial.Columns["colID"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewHistorial.Columns["colFecha"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewHistorial.Columns["colTotal"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dataGridViewHistorial.Columns["colEstado"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        }

        private void btnReportes_Click(object sender, EventArgs e)
        {
            FormDashboard dashboard = new FormDashboard();
            dashboard.Show();
            this.Hide();
        }

        private void btnClientes_Click(object sender, EventArgs e)
        {
            Registros registros = new Registros();
            registros.Show();
            this.Hide();
        }

        private void btnFacturas_Click(object sender, EventArgs e)
        {
            Historial historial = new Historial();
            historial.Show();
            this.Hide();
        }

        private void btnProductos_Click(object sender, EventArgs e)
        {
            CRUDFACTURAS cRUDFACTURAS = new CRUDFACTURAS();
            cRUDFACTURAS.Show();
            this.Hide();
        }

        private void btnCrudProductos_Click(object sender, EventArgs e)
        {
            CRUDPRODUCTOS cRUDPRODUCTOS = new CRUDPRODUCTOS();
            cRUDPRODUCTOS.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Contabilidad contabilidad = new Contabilidad();
            contabilidad.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DTE dte = new DTE();
            dte.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            CrudEmpleados crudEmpleados = new CrudEmpleados();
            crudEmpleados.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            CrudClientes crudclientes = new CrudClientes();
            crudclientes.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            CrudAdmin crudadmin = new CrudAdmin();
            crudadmin.Show();
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Configuracion configuracion = new Configuracion();
            configuracion.Show();
            this.Hide();
        }
    }
}
