﻿namespace Practica1
{
    partial class FormFactura
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormFactura));
            cmbTipo = new ComboBox();
            dgvSeleccionados = new DataGridView();
            Producto = new DataGridViewTextBoxColumn();
            Cantidad = new DataGridViewTextBoxColumn();
            Precio = new DataGridViewTextBoxColumn();
            SubTotal = new DataGridViewTextBoxColumn();
            btnCerrar = new Button();
            btnIngresar = new Button();
            btnAgregar = new Button();
            clbProductos = new CheckedListBox();
            dtpFecha = new DateTimePicker();
            cmbCliente = new ComboBox();
            txtNoFactura = new TextBox();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)dgvSeleccionados).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // cmbTipo
            // 
            cmbTipo.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbTipo.FormattingEnabled = true;
            cmbTipo.Location = new Point(427, 302);
            cmbTipo.Name = "cmbTipo";
            cmbTipo.Size = new Size(347, 28);
            cmbTipo.TabIndex = 35;
            // 
            // dgvSeleccionados
            // 
            dgvSeleccionados.AllowUserToAddRows = false;
            dgvSeleccionados.AllowUserToDeleteRows = false;
            dgvSeleccionados.BackgroundColor = Color.FromArgb(240, 240, 250);
            dgvSeleccionados.BorderStyle = BorderStyle.None;
            dgvSeleccionados.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dgvSeleccionados.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dgvSeleccionados.ColumnHeadersHeight = 35;
            dgvSeleccionados.Columns.AddRange(new DataGridViewColumn[] { Producto, Cantidad, Precio, SubTotal });
            dgvSeleccionados.EnableHeadersVisualStyles = false;
            dgvSeleccionados.Location = new Point(151, 552);
            dgvSeleccionados.Name = "dgvSeleccionados";
            dgvSeleccionados.ReadOnly = true;
            dgvSeleccionados.RowHeadersVisible = false;
            dgvSeleccionados.RowHeadersWidth = 51;
            dgvSeleccionados.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvSeleccionados.Size = new Size(676, 101);
            dgvSeleccionados.TabIndex = 33;
            // 
            // Producto
            // 
            Producto.HeaderText = "Producto";
            Producto.MinimumWidth = 6;
            Producto.Name = "Producto";
            Producto.ReadOnly = true;
            Producto.Width = 300;
            // 
            // Cantidad
            // 
            Cantidad.HeaderText = "Cantidad";
            Cantidad.MinimumWidth = 6;
            Cantidad.Name = "Cantidad";
            Cantidad.ReadOnly = true;
            Cantidad.Width = 125;
            // 
            // Precio
            // 
            Precio.HeaderText = "Precio";
            Precio.MinimumWidth = 6;
            Precio.Name = "Precio";
            Precio.ReadOnly = true;
            Precio.Width = 125;
            // 
            // SubTotal
            // 
            SubTotal.HeaderText = "SubTotal";
            SubTotal.MinimumWidth = 6;
            SubTotal.Name = "SubTotal";
            SubTotal.ReadOnly = true;
            SubTotal.Width = 125;
            // 
            // btnCerrar
            // 
            btnCerrar.BackColor = Color.FromArgb(192, 192, 255);
            btnCerrar.Font = new Font("Copperplate Gothic Light", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnCerrar.Location = new Point(612, 659);
            btnCerrar.Name = "btnCerrar";
            btnCerrar.Size = new Size(164, 49);
            btnCerrar.TabIndex = 30;
            btnCerrar.Text = "CERRAR VENTANA";
            btnCerrar.UseVisualStyleBackColor = false;
            btnCerrar.Click += btnCerrar_Click;
            // 
            // btnIngresar
            // 
            btnIngresar.BackColor = Color.FromArgb(192, 192, 255);
            btnIngresar.Font = new Font("Copperplate Gothic Light", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnIngresar.Location = new Point(210, 659);
            btnIngresar.Name = "btnIngresar";
            btnIngresar.Size = new Size(164, 49);
            btnIngresar.TabIndex = 29;
            btnIngresar.Text = "INGRESAR FACTURA";
            btnIngresar.UseVisualStyleBackColor = false;
            btnIngresar.Click += btnIngresar_Click;
            // 
            // btnAgregar
            // 
            btnAgregar.BackColor = Color.FromArgb(192, 192, 255);
            btnAgregar.Font = new Font("Copperplate Gothic Light", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnAgregar.Location = new Point(98, 396);
            btnAgregar.Name = "btnAgregar";
            btnAgregar.Size = new Size(120, 32);
            btnAgregar.TabIndex = 28;
            btnAgregar.Text = "Agregar";
            btnAgregar.UseVisualStyleBackColor = false;
            btnAgregar.Click += btnAgregar_Click;
            // 
            // clbProductos
            // 
            clbProductos.BackColor = Color.FromArgb(240, 240, 250);
            clbProductos.BorderStyle = BorderStyle.FixedSingle;
            clbProductos.Font = new Font("Segoe UI", 10F);
            clbProductos.FormattingEnabled = true;
            clbProductos.Location = new Point(224, 396);
            clbProductos.Name = "clbProductos";
            clbProductos.Size = new Size(629, 77);
            clbProductos.TabIndex = 27;
            // 
            // dtpFecha
            // 
            dtpFecha.Font = new Font("Segoe UI", 10F);
            dtpFecha.Format = DateTimePickerFormat.Short;
            dtpFecha.Location = new Point(427, 266);
            dtpFecha.Name = "dtpFecha";
            dtpFecha.Size = new Size(347, 30);
            dtpFecha.TabIndex = 24;
            // 
            // cmbCliente
            // 
            cmbCliente.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbCliente.FormattingEnabled = true;
            cmbCliente.Location = new Point(427, 221);
            cmbCliente.Name = "cmbCliente";
            cmbCliente.Size = new Size(347, 28);
            cmbCliente.TabIndex = 23;
            // 
            // txtNoFactura
            // 
            txtNoFactura.Font = new Font("Segoe UI", 10F);
            txtNoFactura.Location = new Point(427, 185);
            txtNoFactura.Name = "txtNoFactura";
            txtNoFactura.Size = new Size(347, 30);
            txtNoFactura.TabIndex = 22;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(0, -4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(986, 722);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 36;
            pictureBox1.TabStop = false;
            // 
            // FormFactura
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(942, 712);
            Controls.Add(btnCerrar);
            Controls.Add(btnIngresar);
            Controls.Add(dgvSeleccionados);
            Controls.Add(btnAgregar);
            Controls.Add(clbProductos);
            Controls.Add(cmbTipo);
            Controls.Add(dtpFecha);
            Controls.Add(cmbCliente);
            Controls.Add(txtNoFactura);
            Controls.Add(pictureBox1);
            Name = "FormFactura";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FormFactura";
            Load += FormFactura_Load;
            ((System.ComponentModel.ISupportInitialize)dgvSeleccionados).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox txtNoFactura;
        private ComboBox cmbCliente;
        private DateTimePicker dtpFecha;
        private CheckedListBox clbProductos;
        private Button btnAgregar;
        private Button btnIngresar;
        private Button btnCerrar;
        private DataGridView dgvSeleccionados;
        private DataGridViewTextBoxColumn Producto;
        private DataGridViewTextBoxColumn Cantidad;
        private DataGridViewTextBoxColumn Precio;
        private DataGridViewTextBoxColumn SubTotal;
        private ComboBox cmbTipo;
        private PictureBox pictureBox1;
    }
}
