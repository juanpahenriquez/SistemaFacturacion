﻿namespace Practica1
{
    partial class CrudEmpleados
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            panelTop = new Panel();
            labelTitulo = new Label();
            label6 = new Label();
            label7 = new Label();
            panelSidebar = new Panel();
            btnCrudProductos = new Button();
            button6 = new Button();
            label5 = new Label();
            button5 = new Button();
            button4 = new Button();
            button3 = new Button();
            label3 = new Label();
            button2 = new Button();
            button1 = new Button();
            label2 = new Label();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            btnReportes = new Button();
            btnProductos = new Button();
            btnFacturas = new Button();
            btnClientes = new Button();
            btnGenerar = new Button();
            dgvEmpleados = new DataGridView();
            colID = new DataGridViewTextBoxColumn();
            colCliente = new DataGridViewTextBoxColumn();
            colFecha = new DataGridViewTextBoxColumn();
            colTotal = new DataGridViewTextBoxColumn();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Estado = new DataGridViewTextBoxColumn();
            Editar = new DataGridViewButtonColumn();
            Eliminar = new DataGridViewButtonColumn();
            panelTop.SuspendLayout();
            panelSidebar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvEmpleados).BeginInit();
            SuspendLayout();
            // 
            // panelTop
            // 
            panelTop.BackColor = Color.FromArgb(192, 192, 255);
            panelTop.Controls.Add(labelTitulo);
            panelTop.Controls.Add(label6);
            panelTop.Controls.Add(label7);
            panelTop.Location = new Point(241, 0);
            panelTop.Name = "panelTop";
            panelTop.Size = new Size(1684, 145);
            panelTop.TabIndex = 3;
            // 
            // labelTitulo
            // 
            labelTitulo.AutoSize = true;
            labelTitulo.Font = new Font("Copperplate Gothic Light", 20F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelTitulo.ForeColor = Color.White;
            labelTitulo.Location = new Point(41, 52);
            labelTitulo.Name = "labelTitulo";
            labelTitulo.Size = new Size(372, 37);
            labelTitulo.TabIndex = 17;
            labelTitulo.Text = "CRUD EMPLEADOS";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.Location = new Point(-10, 56);
            label6.Name = "label6";
            label6.Size = new Size(20, 31);
            label6.TabIndex = 15;
            label6.Text = "|";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.Location = new Point(-10, 25);
            label7.Name = "label7";
            label7.Size = new Size(20, 31);
            label7.TabIndex = 3;
            label7.Text = "|";
            // 
            // panelSidebar
            // 
            panelSidebar.BackColor = Color.FromArgb(138, 138, 255);
            panelSidebar.Controls.Add(btnCrudProductos);
            panelSidebar.Controls.Add(button6);
            panelSidebar.Controls.Add(label5);
            panelSidebar.Controls.Add(button5);
            panelSidebar.Controls.Add(button4);
            panelSidebar.Controls.Add(button3);
            panelSidebar.Controls.Add(label3);
            panelSidebar.Controls.Add(button2);
            panelSidebar.Controls.Add(button1);
            panelSidebar.Controls.Add(label2);
            panelSidebar.Controls.Add(label1);
            panelSidebar.Controls.Add(pictureBox1);
            panelSidebar.Controls.Add(btnReportes);
            panelSidebar.Controls.Add(btnProductos);
            panelSidebar.Controls.Add(btnFacturas);
            panelSidebar.Controls.Add(btnClientes);
            panelSidebar.Location = new Point(0, 0);
            panelSidebar.Name = "panelSidebar";
            panelSidebar.Size = new Size(241, 1054);
            panelSidebar.TabIndex = 2;
            // 
            // btnCrudProductos
            // 
            btnCrudProductos.BackColor = Color.Indigo;
            btnCrudProductos.FlatAppearance.BorderSize = 0;
            btnCrudProductos.FlatStyle = FlatStyle.Flat;
            btnCrudProductos.Font = new Font("Century Schoolbook", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnCrudProductos.ForeColor = Color.White;
            btnCrudProductos.Location = new Point(12, 583);
            btnCrudProductos.Name = "btnCrudProductos";
            btnCrudProductos.Size = new Size(213, 41);
            btnCrudProductos.TabIndex = 17;
            btnCrudProductos.Text = "🍔PRODUCTOS";
            btnCrudProductos.UseVisualStyleBackColor = false;
            btnCrudProductos.Click += btnCrudProductos_Click;
            // 
            // button6
            // 
            button6.BackColor = Color.Indigo;
            button6.FlatAppearance.BorderSize = 0;
            button6.FlatStyle = FlatStyle.Flat;
            button6.Font = new Font("Century Schoolbook", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            button6.ForeColor = Color.White;
            button6.Location = new Point(12, 879);
            button6.Name = "button6";
            button6.Size = new Size(213, 41);
            button6.TabIndex = 16;
            button6.Text = "⚙️ Configuracion";
            button6.UseVisualStyleBackColor = false;
            button6.Click += button6_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.FromArgb(138, 138, 255);
            label5.Font = new Font("Copperplate Gothic Light", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.White;
            label5.Location = new Point(52, 839);
            label5.Name = "label5";
            label5.Size = new Size(135, 25);
            label5.TabIndex = 15;
            label5.Text = "GENERAL";
            // 
            // button5
            // 
            button5.BackColor = Color.Indigo;
            button5.FlatAppearance.BorderSize = 0;
            button5.FlatStyle = FlatStyle.Flat;
            button5.Font = new Font("Century Schoolbook", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            button5.ForeColor = Color.White;
            button5.Location = new Point(12, 782);
            button5.Name = "button5";
            button5.Size = new Size(213, 41);
            button5.TabIndex = 14;
            button5.Text = "⌨️ CRUD Admin";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // button4
            // 
            button4.BackColor = Color.Indigo;
            button4.FlatAppearance.BorderSize = 0;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Century Schoolbook", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            button4.ForeColor = Color.White;
            button4.Location = new Point(12, 735);
            button4.Name = "button4";
            button4.Size = new Size(213, 41);
            button4.TabIndex = 13;
            button4.Text = "🚻 CRUD Clientes";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.Indigo;
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Century Schoolbook", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            button3.ForeColor = Color.White;
            button3.Location = new Point(12, 688);
            button3.Name = "button3";
            button3.Size = new Size(213, 41);
            button3.TabIndex = 12;
            button3.Text = "👨CRUD Empleados";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.FromArgb(138, 138, 255);
            label3.Font = new Font("Copperplate Gothic Light", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.White;
            label3.Location = new Point(70, 644);
            label3.Name = "label3";
            label3.Size = new Size(125, 25);
            label3.TabIndex = 11;
            label3.Text = "Usuarios";
            // 
            // button2
            // 
            button2.BackColor = Color.Indigo;
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Century Schoolbook", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.White;
            button2.Location = new Point(12, 533);
            button2.Name = "button2";
            button2.Size = new Size(213, 41);
            button2.TabIndex = 10;
            button2.Text = "✉️ DTE";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.Indigo;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Century Schoolbook", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.White;
            button1.Location = new Point(12, 486);
            button1.Name = "button1";
            button1.Size = new Size(213, 41);
            button1.TabIndex = 9;
            button1.Text = "💰 Contabilidad";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.FromArgb(138, 138, 255);
            label2.Font = new Font("Copperplate Gothic Light", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(28, 402);
            label2.Name = "label2";
            label2.Size = new Size(197, 25);
            label2.TabIndex = 8;
            label2.Text = "Administrativo";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.FromArgb(138, 138, 255);
            label1.Font = new Font("Copperplate Gothic Light", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(69, 220);
            label1.Name = "label1";
            label1.Size = new Size(129, 25);
            label1.TabIndex = 7;
            label1.Text = "Principal";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Control_Panel_bro;
            pictureBox1.Location = new Point(30, 25);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(195, 182);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 6;
            pictureBox1.TabStop = false;
            // 
            // btnReportes
            // 
            btnReportes.BackColor = Color.Indigo;
            btnReportes.FlatAppearance.BorderSize = 0;
            btnReportes.FlatStyle = FlatStyle.Flat;
            btnReportes.Font = new Font("Century Schoolbook", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnReportes.ForeColor = Color.White;
            btnReportes.Location = new Point(12, 254);
            btnReportes.Name = "btnReportes";
            btnReportes.Size = new Size(213, 41);
            btnReportes.TabIndex = 5;
            btnReportes.Text = "📉 Dashboard";
            btnReportes.UseVisualStyleBackColor = false;
            btnReportes.Click += btnReportes_Click;
            // 
            // btnProductos
            // 
            btnProductos.BackColor = Color.Indigo;
            btnProductos.FlatAppearance.BorderSize = 0;
            btnProductos.FlatStyle = FlatStyle.Flat;
            btnProductos.Font = new Font("Century Schoolbook", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnProductos.ForeColor = Color.White;
            btnProductos.Location = new Point(12, 439);
            btnProductos.Name = "btnProductos";
            btnProductos.Size = new Size(213, 41);
            btnProductos.TabIndex = 4;
            btnProductos.Text = "📚 CRUD Facturas";
            btnProductos.UseVisualStyleBackColor = false;
            btnProductos.Click += btnProductos_Click;
            // 
            // btnFacturas
            // 
            btnFacturas.BackColor = Color.Indigo;
            btnFacturas.FlatAppearance.BorderSize = 0;
            btnFacturas.FlatStyle = FlatStyle.Flat;
            btnFacturas.Font = new Font("Century Schoolbook", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnFacturas.ForeColor = Color.White;
            btnFacturas.Location = new Point(12, 348);
            btnFacturas.Name = "btnFacturas";
            btnFacturas.Size = new Size(213, 41);
            btnFacturas.TabIndex = 3;
            btnFacturas.Text = "📖 Historial";
            btnFacturas.UseVisualStyleBackColor = false;
            btnFacturas.Click += btnFacturas_Click;
            // 
            // btnClientes
            // 
            btnClientes.BackColor = Color.Indigo;
            btnClientes.FlatAppearance.BorderSize = 0;
            btnClientes.FlatStyle = FlatStyle.Flat;
            btnClientes.Font = new Font("Century Schoolbook", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnClientes.ForeColor = Color.White;
            btnClientes.Location = new Point(12, 301);
            btnClientes.Name = "btnClientes";
            btnClientes.Size = new Size(213, 41);
            btnClientes.TabIndex = 2;
            btnClientes.Text = "🗓️ Registro";
            btnClientes.UseVisualStyleBackColor = false;
            btnClientes.Click += btnClientes_Click;
            // 
            // btnGenerar
            // 
            btnGenerar.BackColor = Color.FromArgb(192, 192, 255);
            btnGenerar.Font = new Font("Copperplate Gothic Light", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnGenerar.Location = new Point(354, 184);
            btnGenerar.Name = "btnGenerar";
            btnGenerar.Size = new Size(164, 49);
            btnGenerar.TabIndex = 7;
            btnGenerar.Text = "GENERAR ➕";
            btnGenerar.UseVisualStyleBackColor = false;
            btnGenerar.Click += btnGenerar_Click;
            // 
            // dgvEmpleados
            // 
            dgvEmpleados.AllowUserToAddRows = false;
            dgvEmpleados.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(240, 240, 250);
            dataGridViewCellStyle1.ForeColor = Color.FromArgb(45, 45, 68);
            dataGridViewCellStyle1.SelectionBackColor = Color.FromArgb(138, 138, 255);
            dataGridViewCellStyle1.SelectionForeColor = Color.White;
            dgvEmpleados.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dgvEmpleados.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dgvEmpleados.BackgroundColor = Color.White;
            dgvEmpleados.BorderStyle = BorderStyle.None;
            dgvEmpleados.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgvEmpleados.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(107, 107, 217);
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            dataGridViewCellStyle2.ForeColor = Color.White;
            dataGridViewCellStyle2.Padding = new Padding(12, 10, 12, 10);
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            dgvEmpleados.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            dgvEmpleados.ColumnHeadersHeight = 52;
            dgvEmpleados.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgvEmpleados.Columns.AddRange(new DataGridViewColumn[] { colID, colCliente, colFecha, colTotal, Column1, Column2, Estado, Editar, Eliminar });
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.White;
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 10F);
            dataGridViewCellStyle3.ForeColor = Color.FromArgb(45, 45, 68);
            dataGridViewCellStyle3.Padding = new Padding(12, 0, 12, 0);
            dataGridViewCellStyle3.SelectionBackColor = Color.FromArgb(138, 138, 255);
            dataGridViewCellStyle3.SelectionForeColor = Color.White;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            dgvEmpleados.DefaultCellStyle = dataGridViewCellStyle3;
            dgvEmpleados.EnableHeadersVisualStyles = false;
            dgvEmpleados.GridColor = Color.FromArgb(216, 216, 232);
            dgvEmpleados.Location = new Point(282, 276);
            dgvEmpleados.Name = "dgvEmpleados";
            dgvEmpleados.ReadOnly = true;
            dgvEmpleados.RowHeadersVisible = false;
            dgvEmpleados.RowHeadersWidth = 51;
            dgvEmpleados.RowTemplate.Height = 48;
            dgvEmpleados.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvEmpleados.Size = new Size(1630, 722);
            dgvEmpleados.TabIndex = 8;
            // 
            // colID
            // 
            colID.HeaderText = "ID";
            colID.MinimumWidth = 6;
            colID.Name = "colID";
            colID.ReadOnly = true;
            colID.Width = 125;
            // 
            // colCliente
            // 
            colCliente.HeaderText = "Nombre";
            colCliente.MinimumWidth = 6;
            colCliente.Name = "colCliente";
            colCliente.ReadOnly = true;
            colCliente.Width = 250;
            // 
            // colFecha
            // 
            colFecha.HeaderText = "Apellido";
            colFecha.MinimumWidth = 6;
            colFecha.Name = "colFecha";
            colFecha.ReadOnly = true;
            colFecha.Width = 250;
            // 
            // colTotal
            // 
            colTotal.HeaderText = "Usuario";
            colTotal.MinimumWidth = 6;
            colTotal.Name = "colTotal";
            colTotal.ReadOnly = true;
            colTotal.Width = 250;
            // 
            // Column1
            // 
            Column1.AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            Column1.HeaderText = "Correo Electronico";
            Column1.MinimumWidth = 6;
            Column1.Name = "Column1";
            Column1.ReadOnly = true;
            Column1.Width = 229;
            // 
            // Column2
            // 
            Column2.HeaderText = "Contrasenia";
            Column2.MinimumWidth = 6;
            Column2.Name = "Column2";
            Column2.ReadOnly = true;
            Column2.Width = 150;
            // 
            // Estado
            // 
            Estado.HeaderText = "Estado";
            Estado.MinimumWidth = 6;
            Estado.Name = "Estado";
            Estado.ReadOnly = true;
            Estado.Width = 125;
            // 
            // Editar
            // 
            Editar.HeaderText = "Editar";
            Editar.MinimumWidth = 6;
            Editar.Name = "Editar";
            Editar.ReadOnly = true;
            Editar.Resizable = DataGridViewTriState.False;
            Editar.Text = " ✏️ Editar";
            Editar.UseColumnTextForButtonValue = true;
            Editar.Width = 125;
            // 
            // Eliminar
            // 
            Eliminar.HeaderText = "Eliminar";
            Eliminar.MinimumWidth = 6;
            Eliminar.Name = "Eliminar";
            Eliminar.ReadOnly = true;
            Eliminar.Resizable = DataGridViewTriState.False;
            Eliminar.Text = "🚮 Eliminar";
            Eliminar.UseColumnTextForButtonValue = true;
            Eliminar.Width = 125;
            // 
            // CrudEmpleados
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1924, 1055);
            Controls.Add(dgvEmpleados);
            Controls.Add(btnGenerar);
            Controls.Add(panelTop);
            Controls.Add(panelSidebar);
            Name = "CrudEmpleados";
            Text = "CrudEmpleados";
            Load += CrudEmpleados_Load;
            panelTop.ResumeLayout(false);
            panelTop.PerformLayout();
            panelSidebar.ResumeLayout(false);
            panelSidebar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvEmpleados).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panelTop;
        private Label label6;
        private Label label7;
        private Panel panelSidebar;
        private Button button6;
        private Label label5;
        private Button button5;
        private Button button4;
        private Button button3;
        private Label label3;
        private Button button2;
        private Button button1;
        private Label label2;
        private Label label1;
        private PictureBox pictureBox1;
        private Button btnReportes;
        private Button btnProductos;
        private Button btnFacturas;
        private Button btnClientes;
        private Button btnCrudProductos;
        private Button btnGenerar;
        private Label labelTitulo;
        private DataGridView dgvEmpleados;
        private DataGridViewTextBoxColumn colID;
        private DataGridViewTextBoxColumn colCliente;
        private DataGridViewTextBoxColumn colFecha;
        private DataGridViewTextBoxColumn colTotal;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Estado;
        private DataGridViewButtonColumn Editar;
        private DataGridViewButtonColumn Eliminar;
    }
}