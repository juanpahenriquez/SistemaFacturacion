﻿using MySql.Data.MySqlClient;
using Practica1.Clases;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica1
{
    public partial class FormAdmin : Form
    {
        public FormAdmin()
        {
            InitializeComponent();
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            {
                string nombre = txtNombre.Text.Trim();
                string apellido = txtApellido.Text.Trim();
                string telefono = txtTelefono.Text.Trim();
                string correo = txtCorreo.Text.Trim();
                string estado = cmbEstado.Text.Trim();

                if (string.IsNullOrEmpty(nombre) || string.IsNullOrEmpty(apellido) || string.IsNullOrEmpty(telefono) || string.IsNullOrEmpty(correo) || string.IsNullOrEmpty(estado))
                {
                    MessageBox.Show("Por favor complete todos los campos antes de guardar.", "Atención",
                                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string query = "INSERT INTO admin (nombre, apellido, telefono, correo, estado) VALUES (@txtNombre, @txtApellido, @txtTelefono, @txtCorreo, @cmbEstado)";

                using (MySqlConnection conn = conexion.ObtenerConexion())
                {
                    try
                    {
                        conn.Open();
                        using (MySqlCommand cmd = new MySqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@txtNombre", nombre);
                            cmd.Parameters.AddWithValue("@txtApellido", apellido);
                            cmd.Parameters.AddWithValue("@txtTelefono", telefono);
                            cmd.Parameters.AddWithValue("@txtCorreo", correo);
                            cmd.Parameters.AddWithValue("@cmbEstado", estado);

                            cmd.ExecuteNonQuery();
                        }

                        MessageBox.Show("¡Admin registrado con éxito!", "Éxito",
                                        MessageBoxButtons.OK, MessageBoxIcon.Information);

                        this.DialogResult = DialogResult.OK;
                        this.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error al guardar en la base de datos: " + ex.Message, "Error",
                                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void FormAdmin_Load(object sender, EventArgs e)
        {
            if (cmbEstado.Items.Count == 0)
            {
                cmbEstado.Items.Add("Activo");
                cmbEstado.Items.Add("Inactivo");
            }
        }
    }
}
