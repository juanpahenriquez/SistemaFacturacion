﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica1
{
    public partial class Contabilidad : Form
    {
        public Contabilidad()
        {
            InitializeComponent();
            CargarDatosEjemplo();
        }

        private void CargarDatosEjemplo()
        {
            string[] meses = { "Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic" };
            double[] valores = { 1200, 950, 1400, 1100, 1600, 1350, 1800, 1500, 1700, 1900, 2100, 2350 };

            graficoLineas1.SetData(meses, valores);
        }

        private void btnReportes_Click(object sender, EventArgs e)
        {
            FormDashboard dashboard = new FormDashboard();
            dashboard.Show();
            this.Hide();
        }

        private void btnClientes_Click(object sender, EventArgs e)
        {
            Registros registros = new Registros();
            registros.Show();
            this.Hide();
        }

        private void btnFacturas_Click(object sender, EventArgs e)
        {
            Historial historial = new Historial();
            historial.Show();
            this.Hide();
        }

        private void btnProductos_Click(object sender, EventArgs e)
        {
            CRUDFACTURAS cRUDFACTURAS = new CRUDFACTURAS();
            cRUDFACTURAS.Show();
            this.Hide();
        }

        private void btnCrudProductos_Click(object sender, EventArgs e)
        {
            CRUDPRODUCTOS cRUDPRODUCTOS = new CRUDPRODUCTOS();
            cRUDPRODUCTOS.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Contabilidad contabilidad = new Contabilidad();
            contabilidad.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DTE dte = new DTE();
            dte.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            CrudEmpleados crudEmpleados = new CrudEmpleados();
            crudEmpleados.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            CrudClientes crudclientes = new CrudClientes();
            crudclientes.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            CrudAdmin crudadmin = new CrudAdmin();
            crudadmin.Show();
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Configuracion configuracion = new Configuracion();
            configuracion.Show();
            this.Hide();
        }
    }
}
