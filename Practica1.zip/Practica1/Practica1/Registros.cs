﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica1
{
    public partial class Registros : Form
    {
        public Registros()
        {
            InitializeComponent();
            ConfigurarDataGridView();
        }

        private void ConfigurarDataGridView()
        {
            dataGridView1.BackgroundColor = Color.White;
            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridView1.GridColor = Color.FromArgb(216, 216, 232);
            dataGridView1.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;

            dataGridView1.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(107, 107, 217);
            dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            dataGridView1.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView1.ColumnHeadersDefaultCellStyle.Padding = new Padding(12, 10, 12, 10);
            dataGridView1.EnableHeadersVisualStyles = false;
            dataGridView1.ColumnHeadersHeight = 52;

            dataGridView1.DefaultCellStyle.BackColor = Color.White;
            dataGridView1.DefaultCellStyle.ForeColor = Color.FromArgb(45, 45, 68);
            dataGridView1.DefaultCellStyle.Font = new Font("Segoe UI", 10F);
            dataGridView1.DefaultCellStyle.SelectionBackColor = Color.FromArgb(138, 138, 255);
            dataGridView1.DefaultCellStyle.SelectionForeColor = Color.White;
            dataGridView1.DefaultCellStyle.Padding = new Padding(12, 0, 12, 0);

            dataGridView1.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(240, 240, 250);
            dataGridView1.AlternatingRowsDefaultCellStyle.ForeColor = Color.FromArgb(45, 45, 68);
            dataGridView1.AlternatingRowsDefaultCellStyle.SelectionBackColor = Color.FromArgb(138, 138, 255);
            dataGridView1.AlternatingRowsDefaultCellStyle.SelectionForeColor = Color.White;

            dataGridView1.RowTemplate.Height = 48;
            dataGridView1.RowHeadersVisible = false;

            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            dataGridView1.Columns["Column1"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView1.Columns["Column2"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView1.Columns["Column3"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView1.Columns["Column4"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView1.Columns["Column5"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Configuracion configuracion = new Configuracion();
            configuracion.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            CrudAdmin crudadmin = new CrudAdmin();
            crudadmin.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            CrudClientes crudclientes = new CrudClientes();
            crudclientes.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DTE dte = new DTE();
            dte.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Contabilidad contabilidad = new Contabilidad();
            contabilidad.Show();
            this.Hide();
        }

        private void btnFacturas_Click(object sender, EventArgs e)
        {
            Historial historial = new Historial();
            historial.Show();
            this.Hide();
        }

        private void btnProductos_Click(object sender, EventArgs e)
        {
            CRUDFACTURAS cRUDFACTURAS = new CRUDFACTURAS();
            cRUDFACTURAS.Show();
            this.Hide();
        }

        private void btnCrudProductos_Click(object sender, EventArgs e)
        {
            CRUDPRODUCTOS cRUDPRODUCTOS = new CRUDPRODUCTOS();
            cRUDPRODUCTOS.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            CrudEmpleados crudEmpleados = new CrudEmpleados();
            crudEmpleados.Show();
            this.Hide();
        }

        private void btnClientes_Click(object sender, EventArgs e)
        {
            CrudClientes crudclientes = new CrudClientes();
            crudclientes.Show();
            this.Hide();
        }

        private void btnReportes_Click(object sender, EventArgs e)
        {
            FormDashboard dashboard = new FormDashboard();
            dashboard.Show();
            this.Hide();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            FormRegistrodeFactura formRegistrodeFactura = new FormRegistrodeFactura();
            formRegistrodeFactura.Show();
            
        }
    }
}
