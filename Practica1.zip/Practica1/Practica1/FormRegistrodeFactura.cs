﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica1
{
    public partial class FormRegistrodeFactura : Form
    {
        public FormRegistrodeFactura()
        {
            InitializeComponent();
            HacerBotonesTransparentes();
        }

        private void HacerBotonesTransparentes()
        {
            Button[] botones = new Button[] { button7, button1 };

            foreach (var btn in botones)
            {
                HacerBotonTransparente(btn);
            }
        }

        private void HacerBotonTransparente(Button btn)
        {
            // Re-parent al pictureBox para transparencia real sobre la imagen
            var posForm = btn.Location;
            btn.Parent = pictureBox2;
            btn.Location = new Point(
                posForm.X - pictureBox2.Location.X,
                posForm.Y - pictureBox2.Location.Y);

            btn.BackColor = Color.Transparent;
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
            btn.FlatAppearance.BorderColor = Color.FromArgb(0, 255, 255, 255);
            btn.FlatAppearance.MouseOverBackColor = Color.FromArgb(0, 255, 255, 255);
            btn.FlatAppearance.MouseDownBackColor = Color.FromArgb(0, 255, 255, 255);
            btn.FlatAppearance.CheckedBackColor = Color.FromArgb(0, 255, 255, 255);
            btn.UseVisualStyleBackColor = false;
            btn.BringToFront();
        }
    }
}
