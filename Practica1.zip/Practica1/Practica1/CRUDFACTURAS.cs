﻿using MySql.Data.MySqlClient;
using Practica1.Clases;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica1
{
    public partial class CRUDFACTURAS : Form
    {
        public CRUDFACTURAS()
        {
            InitializeComponent();
            HacerBotonesSidebarTransparentes();
            ConfigurarDataGridView();
            CargarFacturas();
        }

        private void HacerBotonesSidebarTransparentes()
        {
            Button[] sidebar = new Button[]
            {
                btnReportes, btnClientes, btnFacturas, btnProductos,
                button1, button2, btnCrudProductos, button3,
                button4, button5, button6
            };

            foreach (var btn in sidebar)
            {
                HacerBotonTransparente(btn);
            }
        }

        private void HacerBotonTransparente(Button btn)
        {
            // Re-parent al pictureBox para transparencia real sobre la imagen
            var posForm = btn.Location;
            btn.Parent = pictureBox1;
            btn.Location = new Point(
                posForm.X - pictureBox1.Location.X,
                posForm.Y - pictureBox1.Location.Y);

            btn.BackColor = Color.Transparent;
            btn.ForeColor = Color.FromArgb(0, 255, 255, 255);
            btn.Text = string.Empty;
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
            btn.FlatAppearance.BorderColor = Color.FromArgb(0, 255, 255, 255);
            btn.FlatAppearance.MouseOverBackColor = Color.FromArgb(0, 255, 255, 255);
            btn.FlatAppearance.MouseDownBackColor = Color.FromArgb(0, 255, 255, 255);
            btn.FlatAppearance.CheckedBackColor = Color.FromArgb(0, 255, 255, 255);
            btn.UseVisualStyleBackColor = false;
            btn.BringToFront();
        }

private void ConfigurarDataGridView()
        {
            dataGridViewFacturas.BackgroundColor = Color.White;
            dataGridViewFacturas.BorderStyle = BorderStyle.None;
            dataGridViewFacturas.GridColor = Color.FromArgb(216, 216, 232);
            dataGridViewFacturas.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dataGridViewFacturas.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;

            dataGridViewFacturas.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(107, 107, 217);
            dataGridViewFacturas.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dataGridViewFacturas.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            dataGridViewFacturas.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewFacturas.ColumnHeadersDefaultCellStyle.Padding = new Padding(12, 10, 12, 10);
            dataGridViewFacturas.EnableHeadersVisualStyles = false;
            dataGridViewFacturas.ColumnHeadersHeight = 52;

            dataGridViewFacturas.DefaultCellStyle.BackColor = Color.White;
            dataGridViewFacturas.DefaultCellStyle.ForeColor = Color.FromArgb(45, 45, 68);
            dataGridViewFacturas.DefaultCellStyle.Font = new Font("Segoe UI", 10F);
            dataGridViewFacturas.DefaultCellStyle.SelectionBackColor = Color.FromArgb(138, 138, 255);
            dataGridViewFacturas.DefaultCellStyle.SelectionForeColor = Color.White;
            dataGridViewFacturas.DefaultCellStyle.Padding = new Padding(12, 0, 12, 0);

            dataGridViewFacturas.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(240, 240, 250);
            dataGridViewFacturas.AlternatingRowsDefaultCellStyle.ForeColor = Color.FromArgb(45, 45, 68);
            dataGridViewFacturas.AlternatingRowsDefaultCellStyle.SelectionBackColor = Color.FromArgb(138, 138, 255);
            dataGridViewFacturas.AlternatingRowsDefaultCellStyle.SelectionForeColor = Color.White;

            dataGridViewFacturas.RowTemplate.Height = 48;
            dataGridViewFacturas.RowHeadersVisible = false;

            dataGridViewFacturas.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            dataGridViewFacturas.Columns["colID"].FillWeight = 10;
            dataGridViewFacturas.Columns["colCliente"].FillWeight = 25;
            dataGridViewFacturas.Columns["colFecha"].FillWeight = 20;
            dataGridViewFacturas.Columns["colTotal"].FillWeight = 15;
            dataGridViewFacturas.Columns["VerDetalle"].FillWeight = 8;
            dataGridViewFacturas.Columns["Column2"].FillWeight = 8;
            dataGridViewFacturas.Columns["Column1"].FillWeight = 8;

            dataGridViewFacturas.Columns["colID"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewFacturas.Columns["colFecha"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewFacturas.Columns["colTotal"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            
        }

        private void btnReportes_Click(object sender, EventArgs e)
        {
            FormDashboard dashboard = new FormDashboard();
            dashboard.Show();
            this.Hide();
        }

        private void btnClientes_Click(object sender, EventArgs e)
        {
            Registros registros = new Registros();
            registros.Show();
            this.Hide();
        }

        private void btnFacturas_Click(object sender, EventArgs e)
        {
            Historial historial = new Historial();
            historial.Show();
            this.Hide();
        }

        private void btnProductos_Click(object sender, EventArgs e)
        {
            CRUDFACTURAS cRUDFACTURAS = new CRUDFACTURAS();
            cRUDFACTURAS.Show();
            this.Hide();
        }

        private void btnCrudProductos_Click(object sender, EventArgs e)
        {
            CRUDPRODUCTOS cRUDPRODUCTOS = new CRUDPRODUCTOS();
            cRUDPRODUCTOS.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Contabilidad contabilidad = new Contabilidad();
            contabilidad.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DTE dte = new DTE();
            dte.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            CrudEmpleados crudEmpleados = new CrudEmpleados();
            crudEmpleados.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            CrudClientes crudclientes = new CrudClientes();
            crudclientes.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            CrudAdmin crudadmin = new CrudAdmin();
            crudadmin.Show();
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Configuracion configuracion = new Configuracion();
            configuracion.Show();
            this.Hide();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            FormFactura formFactura = new FormFactura();
            if (formFactura.ShowDialog() == DialogResult.OK)
            {
                CargarFacturas();
            }
        }

        private void CargarFacturas()
        {
            string query = @"SELECT f.id, CONCAT(c.nombre, ' ', c.apellido) AS cliente, 
                             f.tipo_factura, f.total, f.estado 
                             FROM factura f 
                             INNER JOIN cliente c ON f.cliente_id = c.id";

            using (MySqlConnection conn = conexion.ObtenerConexion())
            {
                try
                {
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    MySqlDataReader reader = cmd.ExecuteReader();

                    dataGridViewFacturas.Rows.Clear();

                    while (reader.Read())
                    {
                        dataGridViewFacturas.Rows.Add(
                            reader["id"].ToString(),
                            reader["cliente"].ToString(),
                            reader["tipo_factura"].ToString(),
                            Convert.ToDecimal(reader["total"]).ToString("C2"),
                            reader["estado"].ToString()
                        );
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al cargar facturas: " + ex.Message, "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void dataGridViewFacturas_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            int facturaId = Convert.ToInt32(dataGridViewFacturas.Rows[e.RowIndex].Cells["colID"].Value);

            if (e.ColumnIndex == dataGridViewFacturas.Columns["VerDetalle"].Index)
            {
                FormDetalleFactura detalle = new FormDetalleFactura(facturaId);
                detalle.ShowDialog();
            }
            else if (e.ColumnIndex == dataGridViewFacturas.Columns["Column2"].Index)
            {
                MessageBox.Show("Funcion Editar pendiente de implementar.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (e.ColumnIndex == dataGridViewFacturas.Columns["Column1"].Index)
            {
                DialogResult result = MessageBox.Show("Desea eliminar esta factura?", "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    EliminarFactura(facturaId);
                }
            }
        }

        private void EliminarFactura(int id)
        {
            string query = "DELETE FROM factura WHERE id = @id";

            using (MySqlConnection conn = conexion.ObtenerConexion())
            {
                try
                {
                    conn.Open();
                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.ExecuteNonQuery();
                    }
                    CargarFacturas();
                    MessageBox.Show("Factura eliminada con exito.", "Exito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al eliminar factura: " + ex.Message, "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
