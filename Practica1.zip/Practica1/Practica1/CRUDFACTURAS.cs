﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica1
{
    public partial class CRUDFACTURAS : Form
    {
        public CRUDFACTURAS()
        {
            InitializeComponent();
            ConfigurarDataGridView();
        }

private void ConfigurarDataGridView()
        {
            dataGridViewFacturas.BackgroundColor = Color.White;
            dataGridViewFacturas.BorderStyle = BorderStyle.None;
            dataGridViewFacturas.GridColor = Color.FromArgb(216, 216, 232);
            dataGridViewFacturas.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dataGridViewFacturas.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;

            dataGridViewFacturas.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(107, 107, 217);
            dataGridViewFacturas.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dataGridViewFacturas.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            dataGridViewFacturas.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewFacturas.ColumnHeadersDefaultCellStyle.Padding = new Padding(12, 10, 12, 10);
            dataGridViewFacturas.EnableHeadersVisualStyles = false;
            dataGridViewFacturas.ColumnHeadersHeight = 52;

            dataGridViewFacturas.DefaultCellStyle.BackColor = Color.White;
            dataGridViewFacturas.DefaultCellStyle.ForeColor = Color.FromArgb(45, 45, 68);
            dataGridViewFacturas.DefaultCellStyle.Font = new Font("Segoe UI", 10F);
            dataGridViewFacturas.DefaultCellStyle.SelectionBackColor = Color.FromArgb(138, 138, 255);
            dataGridViewFacturas.DefaultCellStyle.SelectionForeColor = Color.White;
            dataGridViewFacturas.DefaultCellStyle.Padding = new Padding(12, 0, 12, 0);

            dataGridViewFacturas.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(240, 240, 250);
            dataGridViewFacturas.AlternatingRowsDefaultCellStyle.ForeColor = Color.FromArgb(45, 45, 68);
            dataGridViewFacturas.AlternatingRowsDefaultCellStyle.SelectionBackColor = Color.FromArgb(138, 138, 255);
            dataGridViewFacturas.AlternatingRowsDefaultCellStyle.SelectionForeColor = Color.White;

            dataGridViewFacturas.RowTemplate.Height = 48;
            dataGridViewFacturas.RowHeadersVisible = false;

            dataGridViewFacturas.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            dataGridViewFacturas.Columns["colID"].FillWeight = 15;
            dataGridViewFacturas.Columns["colCliente"].FillWeight = 30;
            dataGridViewFacturas.Columns["colFecha"].FillWeight = 20;
            dataGridViewFacturas.Columns["colTotal"].FillWeight = 15;
            dataGridViewFacturas.Columns["colEstado"].FillWeight = 20;

            dataGridViewFacturas.Columns["colID"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewFacturas.Columns["colFecha"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewFacturas.Columns["colTotal"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dataGridViewFacturas.Columns["colEstado"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        }

        private void btnReportes_Click(object sender, EventArgs e)
        {
            FormDashboard dashboard = new FormDashboard();
            dashboard.Show();
            this.Hide();
        }

        private void btnClientes_Click(object sender, EventArgs e)
        {
            Registros registros = new Registros();
            registros.Show();
            this.Hide();
        }

        private void btnFacturas_Click(object sender, EventArgs e)
        {
            Historial historial = new Historial();
            historial.Show();
            this.Hide();
        }

        private void btnProductos_Click(object sender, EventArgs e)
        {
            CRUDFACTURAS cRUDFACTURAS = new CRUDFACTURAS();
            cRUDFACTURAS.Show();
            this.Hide();
        }

        private void btnCrudProductos_Click(object sender, EventArgs e)
        {
            CRUDPRODUCTOS cRUDPRODUCTOS = new CRUDPRODUCTOS();
            cRUDPRODUCTOS.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Contabilidad contabilidad = new Contabilidad();
            contabilidad.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DTE dte = new DTE();
            dte.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            CrudEmpleados crudEmpleados = new CrudEmpleados();
            crudEmpleados.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            CrudClientes crudclientes = new CrudClientes();
            crudclientes.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            CrudAdmin crudadmin = new CrudAdmin();
            crudadmin.Show();
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Configuracion configuracion = new Configuracion();
            configuracion.Show();
            this.Hide();
        }
    }
}
