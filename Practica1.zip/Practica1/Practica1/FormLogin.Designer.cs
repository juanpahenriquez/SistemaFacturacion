namespace Practica1
{
    partial class FormLogin
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormLogin));
            panelLateral = new Panel();
            pictureBoxLogo = new PictureBox();
            lblBienvenido = new Label();
            panelLogin = new Panel();
            btnSalir = new Button();
            btnIngresar = new Button();
            txtPassword = new TextBox();
            txtUsuario = new TextBox();
            lblPassword = new Label();
            lblUsuario = new Label();
            lblAcceso = new Label();
            panelLateral.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxLogo).BeginInit();
            panelLogin.SuspendLayout();
            SuspendLayout();
            // 
            // panelLateral
            // 
            panelLateral.BackColor = Color.FromArgb(138, 138, 255);
            panelLateral.Controls.Add(pictureBoxLogo);
            panelLateral.Controls.Add(lblBienvenido);
            panelLateral.Dock = DockStyle.Left;
            panelLateral.Location = new Point(0, 0);
            panelLateral.Name = "panelLateral";
            panelLateral.Size = new Size(290, 450);
            panelLateral.TabIndex = 0;
            // 
            // pictureBoxLogo
            // 
            pictureBoxLogo.Image = (Image)resources.GetObject("pictureBoxLogo.Image");
            pictureBoxLogo.Location = new Point(-8, 70);
            pictureBoxLogo.Name = "pictureBoxLogo";
            pictureBoxLogo.Size = new Size(298, 303);
            pictureBoxLogo.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBoxLogo.TabIndex = 2;
            pictureBoxLogo.TabStop = false;
            // 
            // lblBienvenido
            // 
            lblBienvenido.AutoSize = true;
            lblBienvenido.BackColor = Color.FromArgb(192, 192, 255);
            lblBienvenido.Font = new Font("Century Schoolbook", 24F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            lblBienvenido.ForeColor = Color.White;
            lblBienvenido.Location = new Point(50, 347);
            lblBienvenido.Name = "lblBienvenido";
            lblBienvenido.Size = new Size(0, 46);
            lblBienvenido.TabIndex = 1;
            // 
            // panelLogin
            // 
            panelLogin.BackColor = Color.White;
            panelLogin.Controls.Add(btnSalir);
            panelLogin.Controls.Add(btnIngresar);
            panelLogin.Controls.Add(txtPassword);
            panelLogin.Controls.Add(txtUsuario);
            panelLogin.Controls.Add(lblPassword);
            panelLogin.Controls.Add(lblUsuario);
            panelLogin.Controls.Add(lblAcceso);
            panelLogin.Dock = DockStyle.Fill;
            panelLogin.Location = new Point(290, 0);
            panelLogin.Name = "panelLogin";
            panelLogin.Size = new Size(492, 450);
            panelLogin.TabIndex = 1;
            // 
            // btnSalir
            // 
            btnSalir.BackColor = Color.FromArgb(220, 220, 255);
            btnSalir.FlatStyle = FlatStyle.Flat;
            btnSalir.Font = new Font("Century Schoolbook", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnSalir.ForeColor = Color.FromArgb(100, 100, 180);
            btnSalir.Location = new Point(157, 371);
            btnSalir.Name = "btnSalir";
            btnSalir.Size = new Size(170, 38);
            btnSalir.TabIndex = 7;
            btnSalir.Text = "Salir";
            btnSalir.UseVisualStyleBackColor = false;
            btnSalir.Click += btnSalir_Click;
            // 
            // btnIngresar
            // 
            btnIngresar.BackColor = Color.FromArgb(138, 138, 255);
            btnIngresar.FlatStyle = FlatStyle.Flat;
            btnIngresar.Font = new Font("Century Schoolbook", 13.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnIngresar.Location = new Point(157, 295);
            btnIngresar.Name = "btnIngresar";
            btnIngresar.Size = new Size(170, 42);
            btnIngresar.TabIndex = 6;
            btnIngresar.Text = "Ingresar";
            btnIngresar.UseVisualStyleBackColor = false;
            btnIngresar.Click += btnIngresar_Click;
            // 
            // txtPassword
            // 
            txtPassword.BackColor = Color.FromArgb(245, 245, 255);
            txtPassword.BorderStyle = BorderStyle.FixedSingle;
            txtPassword.Font = new Font("Century Schoolbook", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtPassword.Location = new Point(100, 230);
            txtPassword.Name = "txtPassword";
            txtPassword.PasswordChar = '*';
            txtPassword.Size = new Size(290, 32);
            txtPassword.TabIndex = 5;
            // 
            // txtUsuario
            // 
            txtUsuario.BackColor = Color.FromArgb(245, 245, 255);
            txtUsuario.BorderStyle = BorderStyle.FixedSingle;
            txtUsuario.Font = new Font("Century Schoolbook", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtUsuario.Location = new Point(100, 115);
            txtUsuario.Name = "txtUsuario";
            txtUsuario.Size = new Size(290, 32);
            txtUsuario.TabIndex = 4;
            // 
            // lblPassword
            // 
            lblPassword.AutoSize = true;
            lblPassword.Font = new Font("Century Schoolbook", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            lblPassword.ForeColor = Color.FromArgb(80, 80, 160);
            lblPassword.Location = new Point(191, 193);
            lblPassword.Name = "lblPassword";
            lblPassword.Size = new Size(109, 22);
            lblPassword.TabIndex = 3;
            lblPassword.Text = "Contraseña:";
            // 
            // lblUsuario
            // 
            lblUsuario.AutoSize = true;
            lblUsuario.Font = new Font("Century Schoolbook", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            lblUsuario.ForeColor = Color.FromArgb(80, 80, 160);
            lblUsuario.Location = new Point(191, 90);
            lblUsuario.Name = "lblUsuario";
            lblUsuario.Size = new Size(82, 22);
            lblUsuario.TabIndex = 2;
            lblUsuario.Text = "Usuario:";
            // 
            // lblAcceso
            // 
            lblAcceso.AutoSize = true;
            lblAcceso.Font = new Font("Copperplate Gothic Bold", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblAcceso.ForeColor = Color.FromArgb(120, 120, 200);
            lblAcceso.Location = new Point(148, 30);
            lblAcceso.Name = "lblAcceso";
            lblAcceso.Size = new Size(218, 25);
            lblAcceso.TabIndex = 1;
            lblAcceso.Text = "INICIAR SESIÓN";
            // 
            // FormLogin
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(782, 450);
            Controls.Add(panelLogin);
            Controls.Add(panelLateral);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "FormLogin";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Iniciar Sesión - Sistema de Facturación";
            panelLateral.ResumeLayout(false);
            panelLateral.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxLogo).EndInit();
            panelLogin.ResumeLayout(false);
            panelLogin.PerformLayout();
            ResumeLayout(false);
        }

        private Panel panelLateral;
        private Panel panelLogin;
        private Label lblBienvenido;
        private PictureBox pictureBoxLogo;
        private Label lblAcceso;
        private Label lblUsuario;
        private Label lblPassword;
        private TextBox txtUsuario;
        private TextBox txtPassword;
        private Button btnIngresar;
        private Button btnSalir;
    }
}
