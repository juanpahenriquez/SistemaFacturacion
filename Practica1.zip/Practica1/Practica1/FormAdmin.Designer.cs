﻿namespace Practica1
{
    partial class FormAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormAdmin));
            panel1 = new Panel();
            cmbEstado = new ComboBox();
            label7 = new Label();
            txtApellido = new TextBox();
            txtCorreo = new TextBox();
            label6 = new Label();
            txtNombre = new TextBox();
            btnCerrar = new Button();
            btnRegistrar = new Button();
            txtTelefono = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label8 = new Label();
            pictureBox1 = new PictureBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(cmbEstado);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(txtApellido);
            panel1.Controls.Add(txtCorreo);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(txtNombre);
            panel1.Controls.Add(btnCerrar);
            panel1.Controls.Add(btnRegistrar);
            panel1.Controls.Add(txtTelefono);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(pictureBox1);
            panel1.Location = new Point(12, 12);
            panel1.Name = "panel1";
            panel1.Size = new Size(918, 688);
            panel1.TabIndex = 16;
            // 
            // cmbEstado
            // 
            cmbEstado.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbEstado.FormattingEnabled = true;
            cmbEstado.Location = new Point(361, 483);
            cmbEstado.Name = "cmbEstado";
            cmbEstado.Size = new Size(347, 28);
            cmbEstado.TabIndex = 22;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Copperplate Gothic Light", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.Location = new Point(241, 483);
            label7.Name = "label7";
            label7.Size = new Size(107, 21);
            label7.TabIndex = 21;
            label7.Text = "ESTADO:";
            // 
            // txtApellido
            // 
            txtApellido.Location = new Point(360, 333);
            txtApellido.Name = "txtApellido";
            txtApellido.Size = new Size(348, 27);
            txtApellido.TabIndex = 20;
            // 
            // txtCorreo
            // 
            txtCorreo.Location = new Point(360, 433);
            txtCorreo.Name = "txtCorreo";
            txtCorreo.Size = new Size(348, 27);
            txtCorreo.TabIndex = 19;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Copperplate Gothic Light", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.Location = new Point(241, 439);
            label6.Name = "label6";
            label6.Size = new Size(113, 21);
            label6.TabIndex = 18;
            label6.Text = "CORREO:";
            // 
            // txtNombre
            // 
            txtNombre.Location = new Point(360, 286);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(348, 27);
            txtNombre.TabIndex = 16;
            // 
            // btnCerrar
            // 
            btnCerrar.BackColor = Color.FromArgb(192, 192, 255);
            btnCerrar.Font = new Font("Copperplate Gothic Light", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnCerrar.Location = new Point(522, 624);
            btnCerrar.Name = "btnCerrar";
            btnCerrar.Size = new Size(164, 49);
            btnCerrar.TabIndex = 14;
            btnCerrar.Text = "CERRAR VENTANA✖️";
            btnCerrar.UseVisualStyleBackColor = false;
            btnCerrar.Click += btnCerrar_Click;
            // 
            // btnRegistrar
            // 
            btnRegistrar.BackColor = Color.FromArgb(192, 192, 255);
            btnRegistrar.Font = new Font("Copperplate Gothic Light", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnRegistrar.Location = new Point(301, 624);
            btnRegistrar.Name = "btnRegistrar";
            btnRegistrar.Size = new Size(164, 49);
            btnRegistrar.TabIndex = 9;
            btnRegistrar.Text = "REGISTRAR ADMIN➕";
            btnRegistrar.UseVisualStyleBackColor = false;
            btnRegistrar.Click += btnRegistrar_Click;
            // 
            // txtTelefono
            // 
            txtTelefono.Location = new Point(361, 378);
            txtTelefono.Name = "txtTelefono";
            txtTelefono.Size = new Size(348, 27);
            txtTelefono.TabIndex = 11;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Copperplate Gothic Light", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(211, 380);
            label1.Name = "label1";
            label1.Size = new Size(143, 21);
            label1.TabIndex = 10;
            label1.Text = "TELEFONO :";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Copperplate Gothic Light", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(227, 335);
            label2.Name = "label2";
            label2.Size = new Size(127, 21);
            label2.TabIndex = 9;
            label2.Text = "APELLIDO:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Copperplate Gothic Light", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(253, 292);
            label3.Name = "label3";
            label3.Size = new Size(101, 21);
            label3.TabIndex = 6;
            label3.Text = "Nombre:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(-1, 197);
            label4.Name = "label4";
            label4.Size = new Size(1497, 20);
            label4.TabIndex = 5;
            label4.Text = resources.GetString("label4.Text");
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Copperplate Gothic Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Location = new Point(343, 94);
            label5.Name = "label5";
            label5.Size = new Size(341, 31);
            label5.TabIndex = 2;
            label5.Text = "REGISTRO DE ADMIN";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(361, 114);
            label8.Name = "label8";
            label8.Size = new Size(381, 20);
            label8.TabIndex = 3;
            label8.Text = "______________________________________________________________";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Mobile_login_amico;
            pictureBox1.Location = new Point(78, 18);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(200, 176);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // FormAdmin
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(138, 138, 255);
            ClientSize = new Size(942, 712);
            Controls.Add(panel1);
            Name = "FormAdmin";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FormAdmin";
            Load += FormAdmin_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private TextBox txtNombre;
        private Button btnCerrar;
        private Button btnRegistrar;
        private TextBox txtTelefono;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label8;
        private PictureBox pictureBox1;
        private ComboBox cmbEstado;
        private Label label7;
        private TextBox txtApellido;
        private TextBox txtCorreo;
        private Label label6;
    }
}
