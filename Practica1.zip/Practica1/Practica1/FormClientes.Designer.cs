﻿namespace Practica1
{
    partial class FormClientes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormClientes));
            cmbEstado = new ComboBox();
            txtApellido = new TextBox();
            txtCorreo = new TextBox();
            txtNombre = new TextBox();
            btnCerrar = new Button();
            btnRegistrar = new Button();
            txtTelefono = new TextBox();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // cmbEstado
            // 
            cmbEstado.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbEstado.FormattingEnabled = true;
            cmbEstado.Location = new Point(340, 532);
            cmbEstado.Name = "cmbEstado";
            cmbEstado.Size = new Size(347, 28);
            cmbEstado.TabIndex = 22;
            // 
            // txtApellido
            // 
            txtApellido.Location = new Point(340, 310);
            txtApellido.Name = "txtApellido";
            txtApellido.Size = new Size(348, 27);
            txtApellido.TabIndex = 20;
            // 
            // txtCorreo
            // 
            txtCorreo.Location = new Point(340, 458);
            txtCorreo.Name = "txtCorreo";
            txtCorreo.Size = new Size(348, 27);
            txtCorreo.TabIndex = 19;
            // 
            // txtNombre
            // 
            txtNombre.Location = new Point(340, 245);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(348, 27);
            txtNombre.TabIndex = 16;
            // 
            // btnCerrar
            // 
            btnCerrar.BackColor = Color.FromArgb(192, 192, 255);
            btnCerrar.Font = new Font("Copperplate Gothic Light", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnCerrar.Location = new Point(585, 651);
            btnCerrar.Name = "btnCerrar";
            btnCerrar.Size = new Size(164, 49);
            btnCerrar.TabIndex = 14;
            btnCerrar.Text = "CERRAR VENTANA✖️";
            btnCerrar.UseVisualStyleBackColor = false;
            btnCerrar.Click += btnCerrar_Click;
            // 
            // btnRegistrar
            // 
            btnRegistrar.BackColor = Color.FromArgb(192, 192, 255);
            btnRegistrar.Font = new Font("Copperplate Gothic Light", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnRegistrar.Location = new Point(171, 651);
            btnRegistrar.Name = "btnRegistrar";
            btnRegistrar.Size = new Size(164, 49);
            btnRegistrar.TabIndex = 9;
            btnRegistrar.Text = "REGISTRAR CLIENTE➕";
            btnRegistrar.UseVisualStyleBackColor = false;
            btnRegistrar.Click += btnRegistrar_Click;
            // 
            // txtTelefono
            // 
            txtTelefono.Location = new Point(340, 375);
            txtTelefono.Name = "txtTelefono";
            txtTelefono.Size = new Size(348, 27);
            txtTelefono.TabIndex = 11;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(1, -5);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(940, 719);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // FormClientes
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(138, 138, 255);
            ClientSize = new Size(942, 712);
            Controls.Add(cmbEstado);
            Controls.Add(txtApellido);
            Controls.Add(txtCorreo);
            Controls.Add(txtNombre);
            Controls.Add(btnCerrar);
            Controls.Add(txtTelefono);
            Controls.Add(btnRegistrar);
            Controls.Add(pictureBox1);
            Name = "FormClientes";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FormClientes";
            Load += FormClientes_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox txtNombre;
        private Button btnCerrar;
        private Button btnRegistrar;
        private TextBox txtTelefono;
        private PictureBox pictureBox1;
        private ComboBox cmbEstado;
        private TextBox txtApellido;
        private TextBox txtCorreo;
    }
}