﻿using MySql.Data.MySqlClient;
using Practica1.Clases;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica1
{
    public partial class FormClientes : Form
    {
        public FormClientes()
        {
            InitializeComponent();
            HacerBotonesTransparentes();
        }

        private void HacerBotonesTransparentes()
        {
            Button[] botones = new Button[] { btnCerrar, btnRegistrar };

            foreach (var btn in botones)
            {
                HacerBotonTransparente(btn);
            }
        }

        private void HacerBotonTransparente(Button btn)
        {
            // Re-parent al pictureBox para transparencia real sobre la imagen
            var posForm = btn.Location;
            btn.Parent = pictureBox1;
            btn.Location = new Point(
                posForm.X - pictureBox1.Location.X,
                posForm.Y - pictureBox1.Location.Y);

            btn.BackColor = Color.Transparent;
            btn.ForeColor = Color.FromArgb(0, 255, 255, 255);
            btn.Text = string.Empty;
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
            btn.FlatAppearance.BorderColor = Color.FromArgb(0, 255, 255, 255);
            btn.FlatAppearance.MouseOverBackColor = Color.FromArgb(0, 255, 255, 255);
            btn.FlatAppearance.MouseDownBackColor = Color.FromArgb(0, 255, 255, 255);
            btn.FlatAppearance.CheckedBackColor = Color.FromArgb(0, 255, 255, 255);
            btn.UseVisualStyleBackColor = false;
            btn.BringToFront();
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            {
                string nombre = txtNombre.Text.Trim();
                string apellido = txtApellido.Text.Trim();
                string telefono = txtTelefono.Text.Trim();
                string correo = txtCorreo.Text.Trim();
                string estado = cmbEstado.Text.Trim();

                if (string.IsNullOrEmpty(nombre) || string.IsNullOrEmpty(apellido) || string.IsNullOrEmpty(telefono) || string.IsNullOrEmpty(correo) || string.IsNullOrEmpty(estado))
                {
                    MessageBox.Show("Por favor complete todos los campos antes de guardar.", "Atención",
                                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string query = "INSERT INTO cliente (nombre, apellido, telefono, correo, estado) VALUES (@txtNombre, @txtApellido, @txtTelefono, @txtCorreo, @cmbEstado)";

                using (MySqlConnection conn = conexion.ObtenerConexion())
                {
                    try
                    {
                        conn.Open();
                        using (MySqlCommand cmd = new MySqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@txtNombre", nombre);
                            cmd.Parameters.AddWithValue("@txtApellido", apellido);
                            cmd.Parameters.AddWithValue("@txtTelefono", telefono);
                            cmd.Parameters.AddWithValue("@txtCorreo", correo);
                            cmd.Parameters.AddWithValue("@cmbEstado", estado);

                            cmd.ExecuteNonQuery();
                        }

                        MessageBox.Show("¡Cliente registrado con éxito!", "Éxito",
                                        MessageBoxButtons.OK, MessageBoxIcon.Information);

                        this.DialogResult = DialogResult.OK;
                        this.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error al guardar en la base de datos: " + ex.Message, "Error",
                                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void FormClientes_Load(object sender, EventArgs e)
        {
            if (cmbEstado.Items.Count == 0)
            {
                cmbEstado.Items.Add("Activo");
                cmbEstado.Items.Add("Inactivo");
            }
        }
    }
}
