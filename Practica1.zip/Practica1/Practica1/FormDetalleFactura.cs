using MySql.Data.MySqlClient;
using Practica1.Clases;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica1
{
    public partial class FormDetalleFactura : Form
    {
        private readonly int _facturaId;

        // Constructor para el Diseñador de VS
        public FormDetalleFactura()
        {
            InitializeComponent();
        }

        public FormDetalleFactura(int facturaId) : this()
        {
            _facturaId = facturaId;
        }

        private void FormDetalleFactura_Load(object? sender, EventArgs e)
        {
            if (_facturaId > 0)
                CargarDetalle(_facturaId);
        }

        private void CargarDetalle(int facturaId)
        {
            string query = @"SELECT f.no_factura, f.fecha, f.total, f.tipo_factura, f.estado,
                                    CONCAT(c.nombre, ' ', c.apellido) AS cliente
                             FROM factura f
                             INNER JOIN cliente c ON f.cliente_id = c.id
                             WHERE f.id = @id";

            using (MySqlConnection conn = conexion.ObtenerConexion())
            {
                try
                {
                    conn.Open();
                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", facturaId);
                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                lblNoFacturaValor.Text = reader["no_factura"].ToString();
                                lblFechaValor.Text = Convert.ToDateTime(reader["fecha"]).ToString("dd/MM/yyyy");
                                lblClienteValor.Text = reader["cliente"].ToString();
                                lblTipoValor.Text = reader["tipo_factura"].ToString();
                                lblEstadoValor.Text = reader["estado"].ToString();
                                lblTotalValor.Text = Convert.ToDecimal(reader["total"]).ToString("C2");
                            }
                            else
                            {
                                MessageBox.Show("No se encontró la factura.", "Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                                this.Close();
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al cargar el detalle: " + ex.Message, "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.Close();
                }
            }
        }

        private void btnCerrar_Click(object? sender, EventArgs e)
        {
            this.Close();
        }
    }
}
