namespace Practica1
{
    partial class FormDashboard
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            btnRegistro = new Button();
            btnHistorial = new Button();
            btnCRUDFacturas = new Button();
            btnReportes = new Button();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            label2 = new Label();
            btnContabilidad = new Button();
            btnDTE = new Button();
            label3 = new Label();
            btnCRUDEmpleados = new Button();
            btnCRUDClientes = new Button();
            btnCRUDAdmin = new Button();
            label5 = new Label();
            btnConfiguracion = new Button();
            panelSidebar = new Panel();
            button1 = new Button();
            panelTop = new Panel();
            label6 = new Label();
            label7 = new Label();
            panelMain = new Panel();
            label8 = new Label();
            label9 = new Label();
            splitContainer1 = new SplitContainer();
            dataGridView1 = new DataGridView();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panelSidebar.SuspendLayout();
            panelTop.SuspendLayout();
            panelMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)splitContainer1).BeginInit();
            splitContainer1.Panel1.SuspendLayout();
            splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // btnRegistro
            // 
            btnRegistro.BackColor = Color.Indigo;
            btnRegistro.FlatAppearance.BorderSize = 0;
            btnRegistro.FlatStyle = FlatStyle.Flat;
            btnRegistro.Font = new Font("Century Schoolbook", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnRegistro.ForeColor = Color.White;
            btnRegistro.Location = new Point(12, 301);
            btnRegistro.Name = "btnRegistro";
            btnRegistro.Size = new Size(213, 41);
            btnRegistro.TabIndex = 2;
            btnRegistro.Text = "🗓️ Registro";
            btnRegistro.UseVisualStyleBackColor = false;
            btnRegistro.Click += btnRegistro_Click;
            // 
            // btnHistorial
            // 
            btnHistorial.BackColor = Color.Indigo;
            btnHistorial.FlatAppearance.BorderSize = 0;
            btnHistorial.FlatStyle = FlatStyle.Flat;
            btnHistorial.Font = new Font("Century Schoolbook", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnHistorial.ForeColor = Color.White;
            btnHistorial.Location = new Point(12, 348);
            btnHistorial.Name = "btnHistorial";
            btnHistorial.Size = new Size(213, 41);
            btnHistorial.TabIndex = 3;
            btnHistorial.Text = "📖 Historial";
            btnHistorial.UseVisualStyleBackColor = false;
            btnHistorial.Click += btnFacturas_Click;
            // 
            // btnCRUDFacturas
            // 
            btnCRUDFacturas.BackColor = Color.Indigo;
            btnCRUDFacturas.FlatAppearance.BorderSize = 0;
            btnCRUDFacturas.FlatStyle = FlatStyle.Flat;
            btnCRUDFacturas.Font = new Font("Century Schoolbook", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnCRUDFacturas.ForeColor = Color.White;
            btnCRUDFacturas.Location = new Point(12, 439);
            btnCRUDFacturas.Name = "btnCRUDFacturas";
            btnCRUDFacturas.Size = new Size(213, 41);
            btnCRUDFacturas.TabIndex = 4;
            btnCRUDFacturas.Text = "📚 CRUD Facturas";
            btnCRUDFacturas.UseVisualStyleBackColor = false;
            btnCRUDFacturas.Click += btnCRUDFacturas_Click;
            // 
            // btnReportes
            // 
            btnReportes.BackColor = Color.Indigo;
            btnReportes.FlatAppearance.BorderSize = 0;
            btnReportes.FlatStyle = FlatStyle.Flat;
            btnReportes.Font = new Font("Century Schoolbook", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnReportes.ForeColor = Color.White;
            btnReportes.Location = new Point(12, 254);
            btnReportes.Name = "btnReportes";
            btnReportes.Size = new Size(213, 41);
            btnReportes.TabIndex = 5;
            btnReportes.Text = "📉 Dashboard";
            btnReportes.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Control_Panel_bro;
            pictureBox1.Location = new Point(30, 25);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(195, 182);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 6;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.FromArgb(138, 138, 255);
            label1.Font = new Font("Copperplate Gothic Light", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(69, 220);
            label1.Name = "label1";
            label1.Size = new Size(129, 25);
            label1.TabIndex = 7;
            label1.Text = "Principal";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.FromArgb(138, 138, 255);
            label2.Font = new Font("Copperplate Gothic Light", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(28, 402);
            label2.Name = "label2";
            label2.Size = new Size(197, 25);
            label2.TabIndex = 8;
            label2.Text = "Administrativo";
            // 
            // btnContabilidad
            // 
            btnContabilidad.BackColor = Color.Indigo;
            btnContabilidad.FlatAppearance.BorderSize = 0;
            btnContabilidad.FlatStyle = FlatStyle.Flat;
            btnContabilidad.Font = new Font("Century Schoolbook", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnContabilidad.ForeColor = Color.White;
            btnContabilidad.Location = new Point(12, 486);
            btnContabilidad.Name = "btnContabilidad";
            btnContabilidad.Size = new Size(213, 41);
            btnContabilidad.TabIndex = 9;
            btnContabilidad.Text = "💰 Contabilidad";
            btnContabilidad.UseVisualStyleBackColor = false;
            btnContabilidad.Click += btnContabilidad_Click;
            // 
            // btnDTE
            // 
            btnDTE.BackColor = Color.Indigo;
            btnDTE.FlatAppearance.BorderSize = 0;
            btnDTE.FlatStyle = FlatStyle.Flat;
            btnDTE.Font = new Font("Century Schoolbook", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnDTE.ForeColor = Color.White;
            btnDTE.Location = new Point(12, 533);
            btnDTE.Name = "btnDTE";
            btnDTE.Size = new Size(213, 41);
            btnDTE.TabIndex = 10;
            btnDTE.Text = "✉️ DTE";
            btnDTE.UseVisualStyleBackColor = false;
            btnDTE.Click += btnDTE_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.FromArgb(138, 138, 255);
            label3.Font = new Font("Copperplate Gothic Light", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.White;
            label3.Location = new Point(70, 644);
            label3.Name = "label3";
            label3.Size = new Size(125, 25);
            label3.TabIndex = 11;
            label3.Text = "Usuarios";
            // 
            // btnCRUDEmpleados
            // 
            btnCRUDEmpleados.BackColor = Color.Indigo;
            btnCRUDEmpleados.FlatAppearance.BorderSize = 0;
            btnCRUDEmpleados.FlatStyle = FlatStyle.Flat;
            btnCRUDEmpleados.Font = new Font("Century Schoolbook", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnCRUDEmpleados.ForeColor = Color.White;
            btnCRUDEmpleados.Location = new Point(12, 688);
            btnCRUDEmpleados.Name = "btnCRUDEmpleados";
            btnCRUDEmpleados.Size = new Size(213, 41);
            btnCRUDEmpleados.TabIndex = 12;
            btnCRUDEmpleados.Text = "👨CRUD Empleados";
            btnCRUDEmpleados.UseVisualStyleBackColor = false;
            btnCRUDEmpleados.Click += btnCRUDEmpleados_Click;
            // 
            // btnCRUDClientes
            // 
            btnCRUDClientes.BackColor = Color.Indigo;
            btnCRUDClientes.FlatAppearance.BorderSize = 0;
            btnCRUDClientes.FlatStyle = FlatStyle.Flat;
            btnCRUDClientes.Font = new Font("Century Schoolbook", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnCRUDClientes.ForeColor = Color.White;
            btnCRUDClientes.Location = new Point(12, 735);
            btnCRUDClientes.Name = "btnCRUDClientes";
            btnCRUDClientes.Size = new Size(213, 41);
            btnCRUDClientes.TabIndex = 13;
            btnCRUDClientes.Text = "🚻 CRUD Clientes";
            btnCRUDClientes.UseVisualStyleBackColor = false;
            btnCRUDClientes.Click += btnCRUDClientes_Click;
            // 
            // btnCRUDAdmin
            // 
            btnCRUDAdmin.BackColor = Color.Indigo;
            btnCRUDAdmin.FlatAppearance.BorderSize = 0;
            btnCRUDAdmin.FlatStyle = FlatStyle.Flat;
            btnCRUDAdmin.Font = new Font("Century Schoolbook", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnCRUDAdmin.ForeColor = Color.White;
            btnCRUDAdmin.Location = new Point(12, 782);
            btnCRUDAdmin.Name = "btnCRUDAdmin";
            btnCRUDAdmin.Size = new Size(213, 41);
            btnCRUDAdmin.TabIndex = 14;
            btnCRUDAdmin.Text = "⌨️ CRUD Admin";
            btnCRUDAdmin.UseVisualStyleBackColor = false;
            btnCRUDAdmin.Click += btnCRUDAdmin_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.FromArgb(138, 138, 255);
            label5.Font = new Font("Copperplate Gothic Light", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.White;
            label5.Location = new Point(52, 839);
            label5.Name = "label5";
            label5.Size = new Size(135, 25);
            label5.TabIndex = 15;
            label5.Text = "GENERAL";
            // 
            // btnConfiguracion
            // 
            btnConfiguracion.BackColor = Color.Indigo;
            btnConfiguracion.FlatAppearance.BorderSize = 0;
            btnConfiguracion.FlatStyle = FlatStyle.Flat;
            btnConfiguracion.Font = new Font("Century Schoolbook", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnConfiguracion.ForeColor = Color.White;
            btnConfiguracion.Location = new Point(12, 879);
            btnConfiguracion.Name = "btnConfiguracion";
            btnConfiguracion.Size = new Size(213, 41);
            btnConfiguracion.TabIndex = 16;
            btnConfiguracion.Text = "⚙️ Configuracion";
            btnConfiguracion.UseVisualStyleBackColor = false;
            btnConfiguracion.Click += btnConfiguracion_Click;
            // 
            // panelSidebar
            // 
            panelSidebar.BackColor = Color.FromArgb(138, 138, 255);
            panelSidebar.Controls.Add(button1);
            panelSidebar.Controls.Add(btnConfiguracion);
            panelSidebar.Controls.Add(label5);
            panelSidebar.Controls.Add(btnCRUDAdmin);
            panelSidebar.Controls.Add(btnCRUDClientes);
            panelSidebar.Controls.Add(btnCRUDEmpleados);
            panelSidebar.Controls.Add(label3);
            panelSidebar.Controls.Add(btnDTE);
            panelSidebar.Controls.Add(btnContabilidad);
            panelSidebar.Controls.Add(label2);
            panelSidebar.Controls.Add(label1);
            panelSidebar.Controls.Add(pictureBox1);
            panelSidebar.Controls.Add(btnReportes);
            panelSidebar.Controls.Add(btnCRUDFacturas);
            panelSidebar.Controls.Add(btnHistorial);
            panelSidebar.Controls.Add(btnRegistro);
            panelSidebar.Location = new Point(0, 0);
            panelSidebar.Name = "panelSidebar";
            panelSidebar.Size = new Size(241, 1054);
            panelSidebar.TabIndex = 0;
            // 
            // button1
            // 
            button1.BackColor = Color.Indigo;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Century Schoolbook", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.White;
            button1.Location = new Point(12, 583);
            button1.Name = "button1";
            button1.Size = new Size(213, 41);
            button1.TabIndex = 17;
            button1.Text = "🍔PRODUCTOS";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // panelTop
            // 
            panelTop.BackColor = Color.FromArgb(138, 138, 255);
            panelTop.Controls.Add(label6);
            panelTop.Controls.Add(label7);
            panelTop.Location = new Point(241, 0);
            panelTop.Name = "panelTop";
            panelTop.Size = new Size(1684, 145);
            panelTop.TabIndex = 1;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.Location = new Point(-10, 56);
            label6.Name = "label6";
            label6.Size = new Size(20, 31);
            label6.TabIndex = 15;
            label6.Text = "|";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.Location = new Point(-10, 25);
            label7.Name = "label7";
            label7.Size = new Size(20, 31);
            label7.TabIndex = 3;
            label7.Text = "|";
            // 
            // panelMain
            // 
            panelMain.BackColor = Color.White;
            panelMain.Controls.Add(label8);
            panelMain.Controls.Add(label9);
            panelMain.Controls.Add(splitContainer1);
            panelMain.Location = new Point(241, 145);
            panelMain.Name = "panelMain";
            panelMain.Size = new Size(1684, 909);
            panelMain.TabIndex = 1;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.Transparent;
            label8.Font = new Font("Copperplate Gothic Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.Black;
            label8.Location = new Point(599, 44);
            label8.Name = "label8";
            label8.Size = new Size(445, 31);
            label8.TabIndex = 16;
            label8.Text = "SISTEMA DE FACTURACION";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.Font = new Font("Copperplate Gothic Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.Black;
            label9.Location = new Point(584, 58);
            label9.Name = "label9";
            label9.Size = new Size(476, 31);
            label9.TabIndex = 17;
            label9.Text = "_________________________________";
            // 
            // splitContainer1
            // 
            splitContainer1.Location = new Point(335, 144);
            splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            splitContainer1.Panel1.Controls.Add(dataGridView1);
            splitContainer1.Size = new Size(980, 658);
            splitContainer1.SplitterDistance = 474;
            splitContainer1.TabIndex = 2;
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(240, 240, 250);
            dataGridViewCellStyle1.ForeColor = Color.FromArgb(45, 45, 68);
            dataGridViewCellStyle1.SelectionBackColor = Color.FromArgb(138, 138, 255);
            dataGridViewCellStyle1.SelectionForeColor = Color.White;
            dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dataGridView1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dataGridView1.BackgroundColor = Color.White;
            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridView1.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(107, 107, 217);
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            dataGridViewCellStyle2.ForeColor = Color.White;
            dataGridViewCellStyle2.Padding = new Padding(12, 10, 12, 10);
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            dataGridView1.ColumnHeadersHeight = 52;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { Column1, Column2, Column3 });
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.White;
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 10F);
            dataGridViewCellStyle3.ForeColor = Color.FromArgb(45, 45, 68);
            dataGridViewCellStyle3.Padding = new Padding(12, 0, 12, 0);
            dataGridViewCellStyle3.SelectionBackColor = Color.FromArgb(138, 138, 255);
            dataGridViewCellStyle3.SelectionForeColor = Color.White;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            dataGridView1.DefaultCellStyle = dataGridViewCellStyle3;
            dataGridView1.EnableHeadersVisualStyles = false;
            dataGridView1.GridColor = Color.FromArgb(216, 216, 232);
            dataGridView1.Location = new Point(0, 0);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.RowTemplate.Height = 48;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.Size = new Size(474, 655);
            dataGridView1.TabIndex = 0;
            // 
            // Column1
            // 
            Column1.HeaderText = "ID";
            Column1.MinimumWidth = 6;
            Column1.Name = "Column1";
            Column1.ReadOnly = true;
            Column1.Width = 50;
            // 
            // Column2
            // 
            Column2.HeaderText = "Nombre";
            Column2.MinimumWidth = 6;
            Column2.Name = "Column2";
            Column2.ReadOnly = true;
            Column2.Width = 175;
            // 
            // Column3
            // 
            Column3.HeaderText = "Documento";
            Column3.MinimumWidth = 6;
            Column3.Name = "Column3";
            Column3.ReadOnly = true;
            Column3.Width = 200;
            // 
            // FormDashboard
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Indigo;
            ClientSize = new Size(1924, 1055);
            Controls.Add(panelMain);
            Controls.Add(panelTop);
            Controls.Add(panelSidebar);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "FormDashboard";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Dashboard - Sistema de Facturacion";
            WindowState = FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panelSidebar.ResumeLayout(false);
            panelSidebar.PerformLayout();
            panelTop.ResumeLayout(false);
            panelTop.PerformLayout();
            panelMain.ResumeLayout(false);
            panelMain.PerformLayout();
            splitContainer1.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)splitContainer1).EndInit();
            splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private Button btnRegistro;
        private Button btnHistorial;
        private Button btnCRUDFacturas;
        private Button btnReportes;
        private PictureBox pictureBox1;
        private Label label1;
        private Label label2;
        private Button btnContabilidad;
        private Button btnDTE;
        private Label label3;
        private Button btnCRUDEmpleados;
        private Button btnCRUDClientes;
        private Button btnCRUDAdmin;
        private Label label5;
        private Button btnConfiguracion;
        private Panel panelSidebar;
        private Panel panelTop;
        private Label label6;
        private Label label7;
        private Panel panelMain;
private SplitContainer splitContainer1;
        private Label label8;
        private Label label9;
        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private Button button1;
    }
}
