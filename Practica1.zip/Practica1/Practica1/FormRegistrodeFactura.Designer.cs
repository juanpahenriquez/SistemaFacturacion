﻿namespace Practica1
{
    partial class FormRegistrodeFactura
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormRegistrodeFactura));
            button1 = new Button();
            button7 = new Button();
            checkedListBox1 = new CheckedListBox();
            textBox1 = new TextBox();
            comboBox3 = new ComboBox();
            comboBox2 = new ComboBox();
            dateTimePicker2 = new DateTimePicker();
            pictureBox2 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(192, 192, 255);
            button1.Font = new Font("Copperplate Gothic Light", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.Location = new Point(586, 648);
            button1.Name = "button1";
            button1.Size = new Size(164, 49);
            button1.TabIndex = 14;
            button1.Text = "CERRAR VENTANA✖️";
            button1.UseVisualStyleBackColor = false;
            // 
            // button7
            // 
            button7.BackColor = Color.FromArgb(192, 192, 255);
            button7.Font = new Font("Copperplate Gothic Light", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button7.Location = new Point(200, 648);
            button7.Name = "button7";
            button7.Size = new Size(164, 49);
            button7.TabIndex = 9;
            button7.Text = "GENERAR  REGISTRO➕";
            button7.UseVisualStyleBackColor = false;
            // 
            // checkedListBox1
            // 
            checkedListBox1.FormattingEnabled = true;
            checkedListBox1.Items.AddRange(new object[] { "Camarones con chocolate", "Pollo en cebada", "Carne en maizena", "Mango tierno", "Jocotes de corona", "Fresco de cangrejo" });
            checkedListBox1.Location = new Point(258, 473);
            checkedListBox1.Name = "checkedListBox1";
            checkedListBox1.Size = new Size(456, 136);
            checkedListBox1.TabIndex = 12;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(337, 386);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(348, 27);
            textBox1.TabIndex = 11;
            // 
            // comboBox3
            // 
            comboBox3.FormattingEnabled = true;
            comboBox3.Location = new Point(336, 338);
            comboBox3.Name = "comboBox3";
            comboBox3.Size = new Size(349, 28);
            comboBox3.TabIndex = 8;
            // 
            // comboBox2
            // 
            comboBox2.FormattingEnabled = true;
            comboBox2.Location = new Point(337, 294);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(349, 28);
            comboBox2.TabIndex = 7;
            // 
            // dateTimePicker2
            // 
            dateTimePicker2.Location = new Point(337, 249);
            dateTimePicker2.Name = "dateTimePicker2";
            dateTimePicker2.Size = new Size(350, 27);
            dateTimePicker2.TabIndex = 1;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(0, 0);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(943, 717);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 0;
            pictureBox2.TabStop = false;
            // 
            // FormRegistrodeFactura
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(138, 138, 255);
            ClientSize = new Size(942, 712);
            Controls.Add(button7);
            Controls.Add(button1);
            Controls.Add(dateTimePicker2);
            Controls.Add(comboBox2);
            Controls.Add(checkedListBox1);
            Controls.Add(comboBox3);
            Controls.Add(textBox1);
            Controls.Add(pictureBox2);
            Name = "FormRegistrodeFactura";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FormRegistrodeFactura";
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private CheckedListBox checkedListBox1;
        private TextBox textBox1;
        private ComboBox comboBox3;
        private ComboBox comboBox2;
        private DateTimePicker dateTimePicker2;
        private PictureBox pictureBox2;
        private Button button1;
        private Button button7;
    }
}