﻿using MySql.Data.MySqlClient;
using Practica1.Clases;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica1
{
    public partial class FormFactura : Form
    {
        public FormFactura()
        {
            InitializeComponent();
            HacerBotonesTransparentes();
        }

        private void HacerBotonesTransparentes()
        {
            Button[] botones = new Button[] { btnCerrar, btnIngresar, btnAgregar };

            foreach (var btn in botones)
            {
                HacerBotonTransparente(btn);
            }
        }

        private void HacerBotonTransparente(Button btn)
        {
            // Re-parent al pictureBox para transparencia real sobre la imagen
            var posForm = btn.Location;
            btn.Parent = pictureBox1;
            btn.Location = new Point(
                posForm.X - pictureBox1.Location.X,
                posForm.Y - pictureBox1.Location.Y);

            btn.BackColor = Color.Transparent;
            btn.ForeColor = Color.FromArgb(0, 255, 255, 255);
            btn.Text = string.Empty;
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
            btn.FlatAppearance.BorderColor = Color.FromArgb(0, 255, 255, 255);
            btn.FlatAppearance.MouseOverBackColor = Color.FromArgb(0, 255, 255, 255);
            btn.FlatAppearance.MouseDownBackColor = Color.FromArgb(0, 255, 255, 255);
            btn.FlatAppearance.CheckedBackColor = Color.FromArgb(0, 255, 255, 255);
            btn.UseVisualStyleBackColor = false;
            btn.BringToFront();
        }

        private void FormFactura_Load(object sender, EventArgs e)
        {
            cmbTipo.Items.AddRange(new string[] { "Consumidor Final", "Credito Fiscal" });
            cmbTipo.SelectedIndex = 0;

            CargarClientes();
            CargarProductos();
        }

        private void CargarClientes()
        {
            try
            {
                string query = "SELECT id, nombre, apellido FROM cliente WHERE estado = 'Activo'";
                using (MySqlConnection conn = conexion.ObtenerConexion())
                {
                    conn.Open();
                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            cmbCliente.Items.Add(new { Text = reader["nombre"].ToString() + " " + reader["apellido"].ToString(), Value = reader["id"] });
                        }
                    }
                }
                cmbCliente.DisplayMember = "Text";
                cmbCliente.ValueMember = "Value";
                if (cmbCliente.Items.Count > 0) cmbCliente.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar clientes: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CargarProductos()
        {
            try
            {
                string query = "SELECT id, nombre, precio FROM productos";
                using (MySqlConnection conn = conexion.ObtenerConexion())
                {
                    conn.Open();
                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            decimal precio = Convert.ToDecimal(reader["precio"]);
                            clbProductos.Items.Add(new { Text = reader["nombre"].ToString() + " - $" + precio.ToString("F2"), Id = reader["id"], Precio = precio });
                        }
                    }
                }
                clbProductos.DisplayMember = "Text";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar productos: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if (clbProductos.CheckedItems.Count == 0)
            {
                MessageBox.Show("Seleccione al menos un producto.", "Atencion", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            foreach (var item in clbProductos.CheckedItems)
            {
                dynamic prod = item;
                decimal precio = Convert.ToDecimal(prod.Precio);
                decimal subtotal = precio;

                dgvSeleccionados.Rows.Add(prod.Text, 1, precio.ToString("F2"), subtotal.ToString("F2"));
            }

            clbProductos.ClearSelected();
            for (int i = 0; i < clbProductos.Items.Count; i++)
            {
                clbProductos.SetItemChecked(i, false);
            }

            CalcularTotal();
        }

        private void CalcularTotal()
        {
            decimal total = 0;
            foreach (DataGridViewRow row in dgvSeleccionados.Rows)
            {
                if (row.Cells["SubTotal"].Value != null)
                {
                    total += Convert.ToDecimal(row.Cells["SubTotal"].Value);
                }
            }
        }

        private void btnIngresar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNoFactura.Text))
            {
                MessageBox.Show("Ingrese el numero de factura.", "Atencion", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (cmbCliente.SelectedItem == null)
            {
                MessageBox.Show("Seleccione un cliente.", "Atencion", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (dgvSeleccionados.Rows.Count == 0)
            {
                MessageBox.Show("Agregue al menos un producto.", "Atencion", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                dynamic cliente = cmbCliente.SelectedItem;
                int clienteId = cliente.Value;
                string noFactura = txtNoFactura.Text.Trim();
                DateTime fecha = dtpFecha.Value;
                string tipo = cmbTipo.Text;
                decimal total = 0;

                foreach (DataGridViewRow row in dgvSeleccionados.Rows)
                {
                    if (row.Cells["SubTotal"].Value != null)
                        total += Convert.ToDecimal(row.Cells["SubTotal"].Value);
                }

                string queryFactura = "INSERT INTO factura (no_factura, cliente_id, fecha, total, estado, tipo_factura) VALUES (@noFactura, @clienteId, @fecha, @total, 'Activa', @tipoFactura)";

                using (MySqlConnection conn = conexion.ObtenerConexion())
                {
                    conn.Open();
                    using (MySqlCommand cmd = new MySqlCommand(queryFactura, conn))
                    {
                        cmd.Parameters.AddWithValue("@noFactura", noFactura);
                        cmd.Parameters.AddWithValue("@clienteId", clienteId);
                        cmd.Parameters.AddWithValue("@fecha", fecha);
                        cmd.Parameters.AddWithValue("@total", total);
                        cmd.Parameters.AddWithValue("@tipoFactura", tipo);
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Factura registrada con exito!", "Exito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar factura: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void lblTitulo_Click(object sender, EventArgs e)
        {

        }
    }
}
