﻿namespace Practica1
{
    partial class FormFacturas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormFacturas));
            panel1 = new Panel();
            label7 = new Label();
            label9 = new Label();
            label10 = new Label();
            pictureBox2 = new PictureBox();
            panel2 = new Panel();
            button1 = new Button();
            button7 = new Button();
            textBox1 = new TextBox();
            label12 = new Label();
            label11 = new Label();
            comboBox2 = new ComboBox();
            label6 = new Label();
            label1 = new Label();
            label8 = new Label();
            label2 = new Label();
            label3 = new Label();
            dateTimePicker2 = new DateTimePicker();
            pictureBox1 = new PictureBox();
            textBox2 = new TextBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(panel2);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(label9);
            panel1.Controls.Add(label10);
            panel1.Controls.Add(pictureBox2);
            panel1.Location = new Point(12, 12);
            panel1.Name = "panel1";
            panel1.Size = new Size(918, 688);
            panel1.TabIndex = 9;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(-68, 214);
            label7.Name = "label7";
            label7.Size = new Size(1497, 20);
            label7.TabIndex = 9;
            label7.Text = resources.GetString("label7.Text");
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Copperplate Gothic Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label9.Location = new Point(468, 102);
            label9.Name = "label9";
            label9.Size = new Size(188, 31);
            label9.TabIndex = 7;
            label9.Text = "FACTURAS";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(390, 123);
            label10.Name = "label10";
            label10.Size = new Size(381, 20);
            label10.TabIndex = 8;
            label10.Text = "______________________________________________________________";
            label10.Click += label10_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.Top_up_credit_rafiki;
            pictureBox2.Location = new Point(55, 31);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(212, 182);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 6;
            pictureBox2.TabStop = false;
            // 
            // panel2
            // 
            panel2.BackColor = Color.White;
            panel2.BorderStyle = BorderStyle.FixedSingle;
            panel2.Controls.Add(textBox2);
            panel2.Controls.Add(button1);
            panel2.Controls.Add(button7);
            panel2.Controls.Add(textBox1);
            panel2.Controls.Add(label12);
            panel2.Controls.Add(label11);
            panel2.Controls.Add(comboBox2);
            panel2.Controls.Add(label6);
            panel2.Controls.Add(label1);
            panel2.Controls.Add(label8);
            panel2.Controls.Add(label2);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(dateTimePicker2);
            panel2.Controls.Add(pictureBox1);
            panel2.Location = new Point(8, 8);
            panel2.Name = "panel2";
            panel2.Size = new Size(918, 688);
            panel2.TabIndex = 10;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(192, 192, 255);
            button1.Font = new Font("Copperplate Gothic Light", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.Location = new Point(522, 624);
            button1.Name = "button1";
            button1.Size = new Size(164, 49);
            button1.TabIndex = 14;
            button1.Text = "CERRAR VENTANA✖️";
            button1.UseVisualStyleBackColor = false;
            // 
            // button7
            // 
            button7.BackColor = Color.FromArgb(192, 192, 255);
            button7.Font = new Font("Copperplate Gothic Light", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button7.Location = new Point(301, 624);
            button7.Name = "button7";
            button7.Size = new Size(164, 49);
            button7.TabIndex = 9;
            button7.Text = "GENERAR  FACTURA➕";
            button7.UseVisualStyleBackColor = false;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(363, 376);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(348, 27);
            textBox1.TabIndex = 11;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Copperplate Gothic Light", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label12.Location = new Point(242, 378);
            label12.Name = "label12";
            label12.Size = new Size(112, 21);
            label12.TabIndex = 10;
            label12.Text = "DUI O NIT";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Copperplate Gothic Light", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label11.Location = new Point(249, 335);
            label11.Name = "label11";
            label11.Size = new Size(112, 21);
            label11.TabIndex = 9;
            label11.Text = "NIT O DUI";
            // 
            // comboBox2
            // 
            comboBox2.FormattingEnabled = true;
            comboBox2.Location = new Point(362, 285);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(349, 28);
            comboBox2.TabIndex = 7;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Copperplate Gothic Light", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.Location = new Point(253, 292);
            label6.Name = "label6";
            label6.Size = new Size(101, 21);
            label6.TabIndex = 6;
            label6.Text = "Nombre:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(-1, 197);
            label1.Name = "label1";
            label1.Size = new Size(1497, 20);
            label1.TabIndex = 5;
            label1.Text = resources.GetString("label1.Text");
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Copperplate Gothic Light", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.Location = new Point(273, 249);
            label8.Name = "label8";
            label8.Size = new Size(82, 21);
            label8.TabIndex = 4;
            label8.Text = "Fecha:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Copperplate Gothic Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(353, 93);
            label2.Name = "label2";
            label2.Size = new Size(389, 31);
            label2.TabIndex = 2;
            label2.Text = "REGISTRO DE FACTURA";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(361, 114);
            label3.Name = "label3";
            label3.Size = new Size(381, 20);
            label3.TabIndex = 3;
            label3.Text = "______________________________________________________________";
            // 
            // dateTimePicker2
            // 
            dateTimePicker2.Location = new Point(361, 246);
            dateTimePicker2.Name = "dateTimePicker2";
            dateTimePicker2.Size = new Size(350, 27);
            dateTimePicker2.TabIndex = 1;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Mobile_login_amico;
            pictureBox1.Location = new Point(78, 18);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(200, 176);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(360, 335);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(348, 27);
            textBox2.TabIndex = 15;
            // 
            // FormFacturas
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(138, 138, 255);
            ClientSize = new Size(942, 712);
            Controls.Add(panel1);
            Name = "FormFacturas";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FormFacturas";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Label label7;
        private Label label9;
        private Label label10;
        private PictureBox pictureBox2;
        private Panel panel2;
        private Button button1;
        private Button button7;
        private TextBox textBox1;
        private Label label12;
        private Label label11;
        private ComboBox comboBox2;
        private Label label6;
        private Label label1;
        private Label label8;
        private Label label2;
        private Label label3;
        private DateTimePicker dateTimePicker2;
        private PictureBox pictureBox1;
        private TextBox textBox2;
    }
}