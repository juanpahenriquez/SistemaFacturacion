namespace Practica1
{
    partial class FormDetalleFactura
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            lblTitulo = new Label();
            labelSeparador = new Label();
            lblNoFactura = new Label();
            lblNoFacturaValor = new Label();
            lblFecha = new Label();
            lblFechaValor = new Label();
            lblCliente = new Label();
            lblClienteValor = new Label();
            lblTipo = new Label();
            lblTipoValor = new Label();
            lblEstado = new Label();
            lblEstadoValor = new Label();
            lblTotal = new Label();
            lblTotalValor = new Label();
            lblAviso = new Label();
            btnCerrar = new Button();
            panel1.SuspendLayout();
            SuspendLayout();
            //
            // panel1
            //
            panel1.BackColor = Color.White;
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(lblTitulo);
            panel1.Controls.Add(labelSeparador);
            panel1.Controls.Add(lblNoFactura);
            panel1.Controls.Add(lblNoFacturaValor);
            panel1.Controls.Add(lblFecha);
            panel1.Controls.Add(lblFechaValor);
            panel1.Controls.Add(lblCliente);
            panel1.Controls.Add(lblClienteValor);
            panel1.Controls.Add(lblTipo);
            panel1.Controls.Add(lblTipoValor);
            panel1.Controls.Add(lblEstado);
            panel1.Controls.Add(lblEstadoValor);
            panel1.Controls.Add(lblTotal);
            panel1.Controls.Add(lblTotalValor);
            panel1.Controls.Add(lblAviso);
            panel1.Controls.Add(btnCerrar);
            panel1.Location = new Point(12, 12);
            panel1.Name = "panel1";
            panel1.Size = new Size(918, 688);
            panel1.TabIndex = 0;
            //
            // lblTitulo
            //
            lblTitulo.AutoSize = true;
            lblTitulo.Font = new Font("Copperplate Gothic Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblTitulo.Location = new Point(300, 60);
            lblTitulo.Name = "lblTitulo";
            lblTitulo.Size = new Size(360, 31);
            lblTitulo.TabIndex = 0;
            lblTitulo.Text = "DETALLE DE FACTURA";
            //
            // labelSeparador
            //
            labelSeparador.AutoSize = true;
            labelSeparador.Location = new Point(268, 100);
            labelSeparador.Name = "labelSeparador";
            labelSeparador.Size = new Size(381, 20);
            labelSeparador.TabIndex = 1;
            labelSeparador.Text = "______________________________________________________________";
            //
            // lblNoFactura
            //
            lblNoFactura.AutoSize = true;
            lblNoFactura.Font = new Font("Copperplate Gothic Light", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblNoFactura.Location = new Point(180, 160);
            lblNoFactura.Name = "lblNoFactura";
            lblNoFactura.Size = new Size(164, 21);
            lblNoFactura.TabIndex = 2;
            lblNoFactura.Text = "No. FACTURA:";
            //
            // lblNoFacturaValor
            //
            lblNoFacturaValor.AutoSize = true;
            lblNoFacturaValor.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblNoFacturaValor.Location = new Point(380, 158);
            lblNoFacturaValor.Name = "lblNoFacturaValor";
            lblNoFacturaValor.Size = new Size(60, 28);
            lblNoFacturaValor.TabIndex = 3;
            lblNoFacturaValor.Text = "------";
            //
            // lblFecha
            //
            lblFecha.AutoSize = true;
            lblFecha.Font = new Font("Copperplate Gothic Light", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblFecha.Location = new Point(180, 210);
            lblFecha.Name = "lblFecha";
            lblFecha.Size = new Size(92, 21);
            lblFecha.TabIndex = 4;
            lblFecha.Text = "FECHA:";
            //
            // lblFechaValor
            //
            lblFechaValor.AutoSize = true;
            lblFechaValor.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblFechaValor.Location = new Point(380, 208);
            lblFechaValor.Name = "lblFechaValor";
            lblFechaValor.Size = new Size(60, 28);
            lblFechaValor.TabIndex = 5;
            lblFechaValor.Text = "------";
            //
            // lblCliente
            //
            lblCliente.AutoSize = true;
            lblCliente.Font = new Font("Copperplate Gothic Light", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblCliente.Location = new Point(180, 260);
            lblCliente.Name = "lblCliente";
            lblCliente.Size = new Size(112, 21);
            lblCliente.TabIndex = 6;
            lblCliente.Text = "CLIENTE:";
            //
            // lblClienteValor
            //
            lblClienteValor.AutoSize = true;
            lblClienteValor.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblClienteValor.Location = new Point(380, 258);
            lblClienteValor.Name = "lblClienteValor";
            lblClienteValor.Size = new Size(60, 28);
            lblClienteValor.TabIndex = 7;
            lblClienteValor.Text = "------";
            //
            // lblTipo
            //
            lblTipo.AutoSize = true;
            lblTipo.Font = new Font("Copperplate Gothic Light", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblTipo.Location = new Point(180, 310);
            lblTipo.Name = "lblTipo";
            lblTipo.Size = new Size(68, 21);
            lblTipo.TabIndex = 8;
            lblTipo.Text = "TIPO:";
            //
            // lblTipoValor
            //
            lblTipoValor.AutoSize = true;
            lblTipoValor.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblTipoValor.Location = new Point(380, 308);
            lblTipoValor.Name = "lblTipoValor";
            lblTipoValor.Size = new Size(60, 28);
            lblTipoValor.TabIndex = 9;
            lblTipoValor.Text = "------";
            //
            // lblEstado
            //
            lblEstado.AutoSize = true;
            lblEstado.Font = new Font("Copperplate Gothic Light", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblEstado.Location = new Point(180, 360);
            lblEstado.Name = "lblEstado";
            lblEstado.Size = new Size(102, 21);
            lblEstado.TabIndex = 10;
            lblEstado.Text = "ESTADO:";
            //
            // lblEstadoValor
            //
            lblEstadoValor.AutoSize = true;
            lblEstadoValor.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblEstadoValor.Location = new Point(380, 358);
            lblEstadoValor.Name = "lblEstadoValor";
            lblEstadoValor.Size = new Size(60, 28);
            lblEstadoValor.TabIndex = 11;
            lblEstadoValor.Text = "------";
            //
            // lblTotal
            //
            lblTotal.AutoSize = true;
            lblTotal.Font = new Font("Copperplate Gothic Bold", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblTotal.Location = new Point(180, 430);
            lblTotal.Name = "lblTotal";
            lblTotal.Size = new Size(104, 26);
            lblTotal.TabIndex = 12;
            lblTotal.Text = "TOTAL:";
            //
            // lblTotalValor
            //
            lblTotalValor.AutoSize = true;
            lblTotalValor.Font = new Font("Segoe UI", 16F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTotalValor.ForeColor = Color.FromArgb(107, 107, 217);
            lblTotalValor.Location = new Point(378, 424);
            lblTotalValor.Name = "lblTotalValor";
            lblTotalValor.Size = new Size(110, 37);
            lblTotalValor.TabIndex = 13;
            lblTotalValor.Text = "$0.00";
            //
            // lblAviso
            //
            lblAviso.Font = new Font("Segoe UI", 10F, FontStyle.Italic, GraphicsUnit.Point, 0);
            lblAviso.ForeColor = Color.FromArgb(120, 120, 160);
            lblAviso.Location = new Point(180, 490);
            lblAviso.Name = "lblAviso";
            lblAviso.Size = new Size(560, 60);
            lblAviso.TabIndex = 14;
            lblAviso.Text = "Nota: el detalle de productos estará disponible en Fase 2 (tabla detalle_factura).";
            //
            // btnCerrar
            //
            btnCerrar.BackColor = Color.FromArgb(192, 192, 255);
            btnCerrar.Font = new Font("Copperplate Gothic Light", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnCerrar.Location = new Point(377, 600);
            btnCerrar.Name = "btnCerrar";
            btnCerrar.Size = new Size(164, 49);
            btnCerrar.TabIndex = 15;
            btnCerrar.Text = "CERRAR ✖️";
            btnCerrar.UseVisualStyleBackColor = false;
            btnCerrar.Click += btnCerrar_Click;
            //
            // FormDetalleFactura
            //
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(138, 138, 255);
            ClientSize = new Size(942, 712);
            Controls.Add(panel1);
            Name = "FormDetalleFactura";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Detalle de Factura";
            Load += FormDetalleFactura_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Label lblTitulo;
        private Label labelSeparador;
        private Label lblNoFactura;
        private Label lblNoFacturaValor;
        private Label lblFecha;
        private Label lblFechaValor;
        private Label lblCliente;
        private Label lblClienteValor;
        private Label lblTipo;
        private Label lblTipoValor;
        private Label lblEstado;
        private Label lblEstadoValor;
        private Label lblTotal;
        private Label lblTotalValor;
        private Label lblAviso;
        private Button btnCerrar;
    }
}
