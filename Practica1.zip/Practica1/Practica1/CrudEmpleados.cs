﻿using MySql.Data.MySqlClient;
using Practica1.Clases;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica1
{
    public partial class CrudEmpleados : Form
    {
        public CrudEmpleados()
        {
            InitializeComponent();
            CargarEmpleados();
        }

        private void btnReportes_Click(object sender, EventArgs e)
        {
            FormDashboard dashboard = new FormDashboard();
            dashboard.Show();
            this.Hide();
        }

        private void btnClientes_Click(object sender, EventArgs e)
        {
            Registros registros = new Registros();
            registros.Show();
            this.Hide();
        }

        private void btnFacturas_Click(object sender, EventArgs e)
        {
            Historial historial = new Historial();
            historial.Show();
            this.Hide();
        }

        private void btnProductos_Click(object sender, EventArgs e)
        {
            CRUDFACTURAS cRUDFACTURAS = new CRUDFACTURAS();
            cRUDFACTURAS.Show();
            this.Hide();
        }

        private void btnCrudProductos_Click(object sender, EventArgs e)
        {
            CRUDPRODUCTOS cRUDPRODUCTOS = new CRUDPRODUCTOS();
            cRUDPRODUCTOS.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Contabilidad contabilidad = new Contabilidad();
            contabilidad.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DTE dte = new DTE();
            dte.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            CrudEmpleados crudEmpleados = new CrudEmpleados();
            crudEmpleados.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            CrudClientes crudclientes = new CrudClientes();
            crudclientes.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            CrudAdmin crudadmin = new CrudAdmin();
            crudadmin.Show();
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Configuracion configuracion = new Configuracion();
            configuracion.Show();
            this.Hide();
        }

        private void CrudEmpleados_Load(object sender, EventArgs e)
        {

        }

        private void btnGenerar_Click(object sender, EventArgs e)
        {
            FormEmpleados formEmpleados = new FormEmpleados();
            if (formEmpleados.ShowDialog() == DialogResult.OK)
            {
                CargarEmpleados();
            }
        }
        public void CargarEmpleados()
        {
            string query = "Select id, nombre, apellido, usuario, correo, contrasenia, estado FROM empleados";

            using (MySqlConnection conn = conexion.ObtenerConexion())
            {
                try
                {
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    MySqlDataReader reader = cmd.ExecuteReader();

                    dgvEmpleados.Rows.Clear();

                    while (reader.Read())
                    {
                        string contrasenia = reader["contrasenia"].ToString();
                        string contraseniaHash = Convert.ToBase64String(
                            SHA256.HashData(Encoding.UTF8.GetBytes(contrasenia))
                        );

                        dgvEmpleados.Rows.Add(
                            reader["id"].ToString(),
                            reader["nombre"].ToString(),
                             reader["apellido"].ToString(),
                              reader["usuario"].ToString(),
                              reader["correo"].ToString(),
                              contraseniaHash,
                              reader["estado"].ToString()
                        );

                    }
                }

                catch (Exception ex)
                {
                    MessageBox.Show("Error al cargar empleado: " + ex.Message, "Error",
                       MessageBoxButtons.OK, MessageBoxIcon.Error);
                }


            }
        }
        
    }
}
